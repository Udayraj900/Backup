INSERT INTO Book (book_id,book_name,author_name,publisher,category,price) VALUES (1001,"Java: The Complete Reference","Herbert Schildt", "Tata" , "Technology",615);
INSERT INTO Book (book_id,book_name,author_name,publisher,category,price) VALUES (1002,"Matlab Programming","Singh Y. Kirani", "Subhash" , "Technology",232);
INSERT INTO Book (book_id,book_name,author_name,publisher,category,price) VALUES (1003,"Half Girlfriend","Chetan Bhagat", "Tata" , "General",95);
INSERT INTO Book (book_id,book_name,author_name,publisher,category,price)VALUES (1004,"Forge your Future","A.P.J. Abdul Kalam", "Swapna" , "General",200);
INSERT INTO Book (book_id,book_name,author_name,publisher,category,price)VALUES (1005,"The Fault in our Stars","John Green", "Pai" , "Kids",159);
INSERT INTO Book (book_id,book_name,author_name,publisher,category,price)VALUES (1006,"My Little Book","Randall Munroe", "Pai" , "Kids",420);