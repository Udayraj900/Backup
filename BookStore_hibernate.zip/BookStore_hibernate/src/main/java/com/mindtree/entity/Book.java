package com.mindtree.entity;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author RShaw
 *
 */
@Entity
@Table(name="book")
public class Book {

	@Id 
	@Column(name="book_id",nullable=false,unique=true)
	private int bookId;
	@Column(name = "book_name", length = 60)
	private String bookName;
	@Column(name = "author_name", length = 50)
	private String authorName;
	@Column(name = "publisher", length = 50)
	private String publisherName;
	@Column(name = "category", length = 20)
	private String categoryName;
	@Column(name = "price")
	private int price;

	@OneToMany(mappedBy = "book")
	private Collection<Purchase> purchases = new ArrayList<Purchase>();
	
	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}


	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	
	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	
	public String getPublisherName() {
		return publisherName;
	}

	public void setPublisherName(String publisherName) {
		this.publisherName = publisherName;
	}


	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}


	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Book(int bookId, String bookName, String authorName, String publisherName, String categoryName, int price) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.authorName = authorName;
		this.publisherName = publisherName;
		this.categoryName = categoryName;
		this.price = price;
	}

	public Book() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", authorName=" + authorName + ", publisherName="
				+ publisherName + ", categoryName=" + categoryName + ", price=" + price + "]";
	}

	/**
	 * @return the purchases
	 */
	public Collection<Purchase> getPurchases() {
		return purchases;
	}

	/**
	 * @param purchases the purchases to set
	 */
	public void setPurchases(Collection<Purchase> purchases) {
		this.purchases = purchases;
	}

	
}
