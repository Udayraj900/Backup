package com.mindtree.entity;

/**
 * @author RShaw
 *
 */
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="purchase")
public class Purchase {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "purchase_no")
	private int purchaseId;
	@Column(name = "customer_name")
	private String customerName;
	@Column(name = "customer_mobile")
	private String customerMobileNo;
	@Column(name = "purchase_date")
	private LocalDate purchaseDate;
	@Column(name = "amount")
	private int amount;

	@ManyToOne 
	@JoinColumn(name="book_id")
	private Book book;
	
	
	public int getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}

	
	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	
	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	
	public String getCustomerMobileNo() {
		return customerMobileNo;
	}

	public void setCustomerMobileNo(String customerMobileNo) {
		this.customerMobileNo = customerMobileNo;
	}

	
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	
	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public Purchase(Book book, String customerName, String customerMobileNo, LocalDate purchaseDate, int amount) {
		super();
		this.book = book;
		this.customerName = customerName;
		this.customerMobileNo = customerMobileNo;
		this.purchaseDate = purchaseDate;
		this.amount = amount;

	}

	public Purchase() {
		
	}

	public Purchase(int purchaseId, Book book, String customerName, String customerMobileNo, LocalDate purchaseDate,
			int amount) {
		super();
		this.book = book;
		this.customerName = customerName;
		this.customerMobileNo = customerMobileNo;
		this.purchaseDate = purchaseDate;
		this.amount = amount;
		this.purchaseId = purchaseId;
	}

	
		
	

	@Override
	public String toString() {
		return "Purchase [customerName=" + customerName + ", customerMobileNo=" + customerMobileNo + ", purchaseDate="
				+ purchaseDate + ", amount=" + amount + ", purchaseId=" + purchaseId + "]";
	}

}
