package com.mindtree.service;

/**
 * @author RShaw
 *
 */
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import com.mindtree.dao.BookStoreDAOImpl;
import com.mindtree.entity.Book;
import com.mindtree.entity.Purchase;
import com.mindtree.exception.ApplicationException;
import com.mindtree.exception.DAOException;
import com.mindtree.exception.InvalidBookIdException;
import com.mindtree.exception.InvalidCategoryException;
import com.mindtree.exception.InvalidMobileNoException;
/**
 * @author RShaw
 * Book Store System Manager class
 * Business logics are implemented in this class
 */
public class BookStoreSystemManager {

	public static BookStoreDAOImpl bookStoreDAOImpl = new BookStoreDAOImpl();

	/**
	 *  
	 * @return List of distinct category names  
	 * @throws InvalidCategoryException
	 */
	public List<String> getCategoriesList() throws InvalidCategoryException {

		List<Book> bookList = bookStoreDAOImpl.getAllBooks();
		Set<String> booksSet = new TreeSet<String>();
		booksSet = bookList.stream().map(Book::getCategoryName).collect(Collectors.toSet());
		List<String> bookListcategory = new ArrayList<>();
		bookListcategory = booksSet.stream().collect(Collectors.toList());
		bookListcategory.sort((s1, s2) -> s1.length() - (s2.length()));

		return bookListcategory;

	}

	/**
	 * 
	 * @param category
	 * @return sorted list of books for category name , sorted by book name  
	 * @throws ApplicationException
	 */
	public List<Book> getAllBooksbyCategory(String category) throws InvalidCategoryException {

		List<Book> bookList = bookStoreDAOImpl.getAllBooks();
		List<Book> bookListByCategory = bookList.stream()
				.filter(book -> book.getCategoryName().trim().toUpperCase().equals(category.trim().toUpperCase()))
				.collect(Collectors.toList());
		bookListByCategory.sort((c1, c2) -> c1.getBookName().compareTo(c2.getBookName()));

		if (bookListByCategory.isEmpty())
			throw new InvalidCategoryException("Invalid category name, please check your input\n");

		return bookListByCategory;

	}

	/**
	 * 
	 * @param userId
	 * @param customerName
	 * @param mobileNumber
	 * validate Mobile number for valid input
	 * @return purchased book when book purchased successfully.
	 * @throws InvalidBookIdException
	 * @throws InvalidMobileNoException
	 */
	public Purchase purchaseBook(int userId, String customerName, String mobileNumber)
			throws InvalidBookIdException, InvalidMobileNoException {

		LocalDate bookPurchaseDate = LocalDate.now();
		Purchase purchase = null;
		try {
			validateuserBookId(userId);
			validateuserMobileNumber(mobileNumber);
			Book book = bookStoreDAOImpl.getBookById(userId);
			purchase = bookStoreDAOImpl.bookPurchase(book, customerName, mobileNumber, bookPurchaseDate);
		} catch (DAOException e) {
			e.printStackTrace();
		}

		return purchase;
	}

	/**
	 * validate userMobileNumber for valid input
	 * @param userMobileNumber
	 * @throws InvalidMobileNoException
	 */
	public void validateuserMobileNumber(String userMobileNumber) throws InvalidMobileNoException {
		if (userMobileNumber.length() != 10)
			throw new InvalidMobileNoException("Invalid mobile no, please check your input \n");
		if (!userMobileNumber.matches("[0-9]+")) {
			throw new InvalidMobileNoException("Invalid mobile no, please check your input \n");
		}
	}

	/**
	 * 
	 * @param userBookId
	 * validate userBookId for valid input
	 * @throws InvalidBookIdException
	 * @throws DAOException
	 */
	public void validateuserBookId(int userBookId) throws InvalidBookIdException, DAOException {

		if (userBookId <= 0) {
			throw new InvalidBookIdException("Invalid Book ID, please check your input \n");
		} else {
			Book book = bookStoreDAOImpl.getBookById(userBookId);
			if (book.getBookId() != userBookId) {
				throw new InvalidBookIdException("Invalid Book ID, please check your input. \n");
			}
		}
	}

	/**
	 * 
	 * @param category
	 * @param categories
	 * @return true when category name is available in the BOOK table
	 * @throws InvalidCategoryException
	 */
	public boolean getValidCategory(String category, List<String> categories) throws InvalidCategoryException {
		if (!categories.contains(category)) {
			throw new InvalidCategoryException("Invalid category name, please check your input.");
		} else {
			return true;
		}
	}
}
