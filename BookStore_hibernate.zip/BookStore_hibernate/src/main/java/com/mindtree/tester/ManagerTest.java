/**
 * 
 */
package com.mindtree.tester;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.mindtree.exception.InvalidBookIdException;
import com.mindtree.exception.InvalidCategoryException;
import com.mindtree.exception.InvalidMobileNoException;
import com.mindtree.service.BookStoreSystemManager;

/**
 * @author RShaw
 *
 */
public class ManagerTest {

	BookStoreSystemManager manager;

	@Before
	public void setUp() throws Exception {
		manager = new BookStoreSystemManager();

	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testDisplayBooks() {

		assertNotNull(manager.getAllBooksbyCategory("Technology"));

	}

	@Test(expected = InvalidCategoryException.class)
	public void testDisplayBooksInvalidCategory() {

		manager.getAllBooksbyCategory("Management");

	}

	//@Test
//	public void testPurchaseBook() {
//
//		assertEquals(1001, (manager.purchaseBook(1001, "Raj", "9900972900")).getBook().getBookId());
//	}

	@Test(expected = InvalidBookIdException.class)
	public void testPurchaseBookInvalidBookId() {

		manager.purchaseBook(1009, "Raj", "9900972900");

	}

	@Test(expected = InvalidMobileNoException.class)
	public void testPurchaseBookInvalidMobileNo() {

		manager.purchaseBook(1001, "Raj", "9900972");

	}
}
