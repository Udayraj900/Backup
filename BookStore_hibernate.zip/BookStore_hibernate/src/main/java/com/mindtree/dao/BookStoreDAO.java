package com.mindtree.dao;

import java.time.LocalDate;
import java.util.List;

import com.mindtree.entity.Book;
import com.mindtree.entity.Purchase;
import com.mindtree.exception.DAOException;
import com.mindtree.exception.InvalidCategoryException;

/**
 * @author RShaw
 *
 */
public interface BookStoreDAO {

	public List<Book> getAllBooks() throws InvalidCategoryException;

	public Book getBookById(int id) throws DAOException;

	public Purchase bookPurchase(Book book, String Name, String Mobile, LocalDate date) throws DAOException;

}
