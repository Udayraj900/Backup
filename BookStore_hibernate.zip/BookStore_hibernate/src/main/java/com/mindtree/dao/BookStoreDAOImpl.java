package com.mindtree.dao;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.mindtree.entity.Book;
import com.mindtree.entity.Purchase;
import com.mindtree.exception.ApplicationException;
import com.mindtree.exception.DAOException;
import com.mindtree.exception.InvalidBookIdException;
import com.mindtree.exception.InvalidCategoryException;
import com.mindtree.util.HibernateUtil;

/**
 * @author RShaw Database Access Implementation class for access values from
 *         database
 */
public class BookStoreDAOImpl implements BookStoreDAO {

	/**
	 * This method will return a list of All book available in BOOK table
	 */

	@Override
	public List<Book> getAllBooks() throws InvalidCategoryException {

		List<Book> books = new ArrayList<Book>();
		Transaction transaction = null;
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();

		try {

			transaction = session.beginTransaction();
			CriteriaQuery<Book> query = session.getCriteriaBuilder().createQuery(Book.class);
			query.from(Book.class);
			books = session.createQuery(query).getResultList();

		} catch (Exception e) {

			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
			throw new InvalidCategoryException(e.getMessage());
		} finally {
			session.flush();
			session.close();
		}
		return books;
	}

	/**
	 * This method insert a book purchase record into PURCHASE table and return the
	 * inserted purchased book object
	 */
	@Override
	public Purchase bookPurchase(Book book, String name, String mobile, LocalDate date) throws DAOException {
		Purchase purchasedBook = new Purchase();
		
		Serializable id = 0;
		Transaction transaction = null;
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		try {
			transaction = session.beginTransaction();

			purchasedBook.setBook(book);
			purchasedBook.setCustomerName(name);
			purchasedBook.setCustomerMobileNo(mobile);
			purchasedBook.setPurchaseDate(date);
			purchasedBook.setAmount(book.getPrice());
			id  = session.save(purchasedBook);
			if (!id.equals(0)) {
				purchasedBook = new Purchase((int) id, book, name, mobile, date, book.getPrice());
			} else {
				throw new DAOException("Book Purchased failed.");
			}
		} catch (ApplicationException e) {
			e.printStackTrace();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			throw new DAOException("Book Purchased failed...\n");
		} finally {
			session.flush();
			session.close();
		}
		return purchasedBook;
	}

	/**
	 * This method will return a book object searched by valid book id available in
	 * BOOK table
	 */
	@Override
	public Book getBookById(int id) throws InvalidBookIdException, DAOException {

		Book book = new Book();
		//int count = 0;
		Transaction transaction = null;
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		try {
			transaction = session.beginTransaction();
			book = session.get(Book.class, id);
	} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			throw new DAOException("Invalid Book Id, Please check input. \n");
		} finally {
			session.flush();
			session.close();
		}
		return book;
	}

}
