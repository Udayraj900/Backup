/**
 *
 */
package com.mindtree.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * @author RShaw
 * Database Utility class to handle Connections
 */

public class HibernateUtil {
//
//	private static final String DRIVER = "com.mysql.jdbc.Driver";
//	
//	private static final String database = "BookStore_DB";
//	private static final String userName = "root";
//	private static final String password = "Welcome123";
//	private static final String URL = "jdbc:mysql://localhost:3306/";
	
	private static final SessionFactory sessionFactory;

	

	static {
		try {
			sessionFactory = new Configuration().configure().buildSessionFactory();
		} catch (Throwable e) {

			System.err.println("Enitial SessionFactory creation failed" + e);
			throw new ExceptionInInitializerError(e);

		}
	}
	public static SessionFactory getSessionFactory() {

		return sessionFactory;

	}
	    
}
