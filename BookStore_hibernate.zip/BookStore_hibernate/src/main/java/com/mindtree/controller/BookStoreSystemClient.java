package com.mindtree.controller;

import java.sql.SQLException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.mindtree.entity.Book;
import com.mindtree.entity.Purchase;
import com.mindtree.exception.InvalidBookIdException;
import com.mindtree.exception.InvalidCategoryException;
import com.mindtree.exception.InvalidMobileNoException;
import com.mindtree.service.BookStoreSystemManager;

/**
 * @author RShaw
 *
 */
public class BookStoreSystemClient {

	static int choice;
	static String userChoice;
	static Scanner userInput = new Scanner(System.in);
	static Scanner userInput1 = new Scanner(System.in);
	static Scanner choiceInput = new Scanner(System.in);

	public static void main(String[] args) throws InvalidCategoryException, SQLException {

		displayMenuOnConsole();

	}

	public static void displayMenuOnConsole() throws InvalidCategoryException, SQLException {
		boolean exit = false;

		System.out.println("================================================");
		System.out.println("********* Welcome to XYZ Book Store ***********");
		System.out.println("================================================");

		do {
			System.out.println("1. Display book details");
			System.out.println("2. Purchase a book");
			System.out.println("3. Exit");
			System.out.println();
			System.out.print("Enter choice [1-3]: ");

			choice = choiceInput.nextInt();
			switch (choice) {
			case 1:
				System.out.println("--------------------------------------");
				System.out.println("     Available Books Categories       ");
				System.out.println("--------------------------------------");

				dispalyBookDetails();
				break;
			case 2:
				System.out.println("--------------------------");
				System.out.println("     Purchase Book        ");
				System.out.println("--------------------------");

				purchaseBook();
				break;

			case 3:
				System.out.println("Thank You!!! Please visit again!!!");
				exit = true;
				break;
			default:
				System.out.println("\nInvalid Choice : Please enter between 1-3 ... \n");
			}
		} while (!exit);
	}

	private static void purchaseBook() throws SQLException {

		int userBookId = -1;
		String userCustomerName = null;
		String userMobileNumber = null;
		BookStoreSystemManager bookStoreSystemManager = new BookStoreSystemManager();

		try {
			do {
				try {
					System.out.print("Enter book id: ");
					userBookId = Integer.parseInt(userInput1.nextLine());
				} catch (NumberFormatException e) {
					System.err.println("Invalid Book ID, please enter integer value. \n");
				}
			} while (userBookId == -1);

			System.out.print("Enter Customer name: ");
			userCustomerName = userInput1.nextLine();

			System.out.print("Enter Customer Mobile number: ");
			userMobileNumber = userInput1.nextLine();

			Purchase purchaseBook = bookStoreSystemManager.purchaseBook(userBookId, userCustomerName, userMobileNumber);

			if (purchaseBook != null) {
				System.out.println("Book Successfully Purchased.");
				LocalDate purchaseDate = purchaseBook.getPurchaseDate();
				Instant instant = Instant.from(purchaseDate.atStartOfDay(ZoneId.systemDefault()));
				System.out.println("Purchase Number : " + purchaseBook.getPurchaseId());
				System.out.println("Purchase Date   : " + Date.from(instant));
				System.out.println("Purchase Amount : " + purchaseBook.getAmount());
				System.out.println();
			}

		} catch (InvalidBookIdException e) {
			System.err.println(e.getMessage());

		} catch (InvalidMobileNoException e) {
			System.err.println(e.getMessage());

		}

	}

	private static void dispalyBookDetails() throws InvalidCategoryException {
		String userCategory;
		BookStoreSystemManager bookStoreSystemManager = new BookStoreSystemManager();

		List<String> categories = bookStoreSystemManager.getCategoriesList();
		System.out.println("Enter the Category " + categories + " : ");
		userCategory = userInput.nextLine().trim().toUpperCase();
		List<String> categoriesTemp = categories.stream().map(s -> s.toUpperCase()).collect(Collectors.toList());
		try {
			boolean searchResults = bookStoreSystemManager.getValidCategory(userCategory, categoriesTemp);
			if (searchResults) {
				List<Book> books = bookStoreSystemManager.getAllBooksbyCategory(userCategory);
				System.out.format("%-5s %-30s %-20s %-20s %-10s", "Id", "Name", "Author", "Publisher", "Price");
				System.out.println();
				for (Book book : books) {
					System.out.format("%-5d %-30s %-20s %-20s %-10d", book.getBookId(), book.getBookName(),
							book.getAuthorName(), book.getPublisherName(), book.getPrice());
					System.out.println();
				}
				System.out.println('\n');
			}
		} catch (InvalidCategoryException e) {
			System.out.println(e.getMessage());
		}
	}
}
