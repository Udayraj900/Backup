package com.mindtree.controller;

import java.time.LocalDate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.mindtree.dao.BookStoreDAOImpl;
import com.mindtree.entity.Book;
import com.mindtree.entity.Purchase;
import com.mindtree.util.HibernateUtil;

public class App {

public static void main(String[] args) {
	
	BookStoreDAOImpl bookStoreDAOImpl = new BookStoreDAOImpl();
	Purchase purchasedBook = new Purchase();
	Purchase purchasedBook2 = new Purchase();
 
	Book book = bookStoreDAOImpl.getBookById(1001);
	Transaction transaction = null;
	SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	Session session = sessionFactory.openSession();
	
	transaction = session.beginTransaction();

		purchasedBook.setBook(book);
		purchasedBook.setCustomerName("RSJ");
		purchasedBook.setCustomerMobileNo("1221233123");
		purchasedBook.setPurchaseDate(LocalDate.now());
		purchasedBook.setAmount(book.getPrice());
		System.out.println(purchasedBook.getBook()+":"+purchasedBook);
		purchasedBook2.setBook(book);
		purchasedBook2.setCustomerName("RSJ");
		purchasedBook2.setCustomerMobileNo("1221233123");
		purchasedBook2.setPurchaseDate(LocalDate.now());
		purchasedBook2.setAmount(book.getPrice());
		
		session.save(purchasedBook);
		session.save(purchasedBook2);
		//session.save(Purchase.class);
		System.out.println("================");
		//session.getTransaction().commit();
		session.flush();
		session.close();
}
}
