package com.mindtree.exception;

/**
 * @author RShaw
 *
 */
public class ApplicationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7277223811836628639L;

	public ApplicationException() {
		super();
	}

	public ApplicationException(String msg) {
		super(msg);

	}

}
