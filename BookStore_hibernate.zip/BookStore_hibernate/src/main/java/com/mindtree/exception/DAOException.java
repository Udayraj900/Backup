package com.mindtree.exception;

/**
 * @author RShaw
 *
 */
public class DAOException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7487853616581809654L;

	public DAOException() {

	}

	public DAOException(String arg0) {
		super(arg0);

	}

	public DAOException(Throwable arg0) {
		super(arg0);

	}

	public DAOException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public DAOException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super();
		// TODO Auto-generated constructor stub
	}

}
