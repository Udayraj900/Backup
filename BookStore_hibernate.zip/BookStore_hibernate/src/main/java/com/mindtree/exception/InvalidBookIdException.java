package com.mindtree.exception;

/**
 * @author RShaw
 *
 */
public class InvalidBookIdException extends ApplicationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5509107162177250076L;

	public InvalidBookIdException() {

	}

	public InvalidBookIdException(String msg) {
		super(msg);

	}

}
