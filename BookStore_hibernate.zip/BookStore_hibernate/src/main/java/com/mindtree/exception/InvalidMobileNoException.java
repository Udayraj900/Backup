package com.mindtree.exception;

/**
 * @author RShaw
 *
 */
public class InvalidMobileNoException extends ApplicationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3886252490098883992L;

	public InvalidMobileNoException() {

	}

	public InvalidMobileNoException(String msg) {
		super(msg);

	}

}
