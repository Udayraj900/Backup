package com.mindtree.exception;

/**
 * @author RShaw
 *
 */
public class InvalidCategoryException extends ApplicationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4086896927262208744L;

	public InvalidCategoryException() {
		super();
	}

	public InvalidCategoryException(String msg) {
		super(msg);

	}

}
