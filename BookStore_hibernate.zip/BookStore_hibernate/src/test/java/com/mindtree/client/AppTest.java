package com.mindtree.client;

import static org.junit.Assert.*;

import org.junit.Test;

import com.mindtree.controller.App;

public class AppTest {
 private App app = new App();
	@Test
	public void test() {
		//assertSame("Hello World!!!!", app.helloWorld());
	}

}
