package com.shaw.onlineshoppingapp.model;

import java.util.List;

import javax.persistence.OneToMany;


public class ShoppingCart {

	
	
	@OneToMany
	private List<Product> products;

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}
	
	
}
