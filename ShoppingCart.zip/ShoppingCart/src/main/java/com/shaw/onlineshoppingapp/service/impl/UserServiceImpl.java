package com.shaw.onlineshoppingapp.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.shaw.onlineshoppingapp.dao.UserRepository;
import com.shaw.onlineshoppingapp.exception.ApplicationException;
import com.shaw.onlineshoppingapp.model.User;
import com.shaw.onlineshoppingapp.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	
	@Autowired
    private UserRepository userRepository;
	
	

    @Bean
    public PasswordEncoder getPasswordEncoder(){
        return new BCryptPasswordEncoder();
    }

   
	@Override
	public User findByUserName(String userName) throws ApplicationException {
		User user = userRepository.findByUserName(userName);
		if(user!= null){
		user.setEncrytedPassword("*******");
		return userRepository.findByUserName(userName);
		}else{
			throw new ApplicationException("User not found for the username: "+userName);
		}
	}
}
