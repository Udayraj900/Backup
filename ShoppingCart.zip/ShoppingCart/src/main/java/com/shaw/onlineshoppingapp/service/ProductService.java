package com.shaw.onlineshoppingapp.service;

import java.util.List;

import com.shaw.onlineshoppingapp.dto.ProductInfo;
import com.shaw.onlineshoppingapp.model.Product;


public interface ProductService {

	public Product findByProductId(Integer prodId);
	
	public Product findByProdName(String prodName);
	
	public List<Product> findProducts();
	
	 
}
