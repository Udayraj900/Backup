package com.shaw.onlineshoppingapp.controller;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ShoppingCartController {

	
	@RequestMapping("/")
	public String home() {
		System.out.println("in index controller");
		return "index";
	}
	
	@RequestMapping(value =  "/login" , method = RequestMethod.GET)
	public String login(Model model) {
		System.out.println("in Login controller");
		return "login";
	}
	
	@RequestMapping(value = { "/accountInfo" }, method = RequestMethod.GET)
	   public String accountInfo(Model model) {
	 
	      UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	      System.out.println(userDetails.getPassword());
	      System.out.println(userDetails.getUsername());
	      System.out.println(userDetails.isEnabled());
	 
	      model.addAttribute("userDetails", userDetails);
	      return "accountInfo";
	   }
}
