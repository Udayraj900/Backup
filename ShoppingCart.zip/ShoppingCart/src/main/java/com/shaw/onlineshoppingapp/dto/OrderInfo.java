package com.shaw.onlineshoppingapp.dto;

import java.util.List;

public class OrderInfo {

	private String id;

	private int orderNum;
	private double amount;

	private List<OrderDetailInfo> details;

	public OrderInfo() {

	}

	
	public OrderInfo(String id, int orderNum, double amount) {
		this.id = id;

		this.orderNum = orderNum;
		this.amount = amount;

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public List<OrderDetailInfo> getDetails() {
		return details;
	}

	public void setDetails(List<OrderDetailInfo> details) {
		this.details = details;
	}

}
