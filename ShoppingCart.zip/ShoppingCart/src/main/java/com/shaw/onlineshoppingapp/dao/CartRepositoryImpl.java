package com.shaw.onlineshoppingapp.dao;

import java.util.List;

import com.shaw.onlineshoppingapp.dto.ProductInfo;

public class CartRepositoryImpl implements CartRepository {

	@Override
	public List<ProductInfo> getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

}
