package com.shaw.onlineshoppingapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.shaw.onlineshoppingapp.model.Product;


@Repository
public interface ProductRepository extends JpaRepository<Product, Integer>{

	public Product findByProductId(Integer prodId);
	
	public Product findByProdName(String prodName);
	
	
	
}
