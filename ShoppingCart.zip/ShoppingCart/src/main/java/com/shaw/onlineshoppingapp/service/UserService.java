package com.shaw.onlineshoppingapp.service;

import com.shaw.onlineshoppingapp.exception.ApplicationException;
import com.shaw.onlineshoppingapp.model.User;


public interface UserService {

	public User findByUserName(String userName) throws ApplicationException;
	
}
