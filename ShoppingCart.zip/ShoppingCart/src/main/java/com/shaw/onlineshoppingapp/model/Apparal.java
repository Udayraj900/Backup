package com.shaw.onlineshoppingapp.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table
@DiscriminatorValue("Apparal")
public class Apparal extends Product{

	private static final long serialVersionUID = 259020763993598267L;

	private String apparalType;
	private String brand;
	private String design;
	
	public Apparal() {
		super();
	}
	
	public String getApparalType() {
		return apparalType;
	}
	public void setType(String apparalType) {
		this.apparalType = apparalType;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getDesign() {
		return design;
	}
	public void setDesign(String design) {
		this.design = design;
	}

	
}
