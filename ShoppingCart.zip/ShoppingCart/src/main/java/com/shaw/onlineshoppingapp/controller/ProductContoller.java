package com.shaw.onlineshoppingapp.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.shaw.onlineshoppingapp.dto.ProductInfo;
import com.shaw.onlineshoppingapp.model.Product;
import com.shaw.onlineshoppingapp.service.ProductService;

@Controller
public class ProductContoller {

	
	@Autowired
	private ProductService productService;
	
	public Product getProductByProductId(Integer prodId) {
		return null;
		
	}
	
	public Product getProductByProdName(String prodName) {
		return null;
		
	}
	
	@RequestMapping({ "/productList" })
	public String  getAllProduct(Model model){
		List<Product> products = productService.findProducts();
		List<ProductInfo> prodInfo = new ArrayList<>();
		
		products.forEach(p->prodInfo.add(new ProductInfo(p.getProductId(),p.getName(),p.getPrice())));
		
		model.addAttribute("viewProducts", prodInfo);
		return "productList";
		
	}
}
