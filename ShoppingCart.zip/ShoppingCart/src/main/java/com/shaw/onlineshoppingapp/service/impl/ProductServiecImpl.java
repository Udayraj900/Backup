package com.shaw.onlineshoppingapp.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shaw.onlineshoppingapp.dao.CartRepository;
import com.shaw.onlineshoppingapp.dao.ProductRepository;
import com.shaw.onlineshoppingapp.dto.ProductInfo;
import com.shaw.onlineshoppingapp.model.Product;
import com.shaw.onlineshoppingapp.service.ProductService;

@Service
public class ProductServiecImpl implements ProductService{

	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private CartRepository cartRepository;
	
	@Override
	public Product findByProductId(Integer prodId) {
		return productRepository.findByProductId(prodId);
	}

	@Override
	public Product findByProdName(String prodName) {
		return productRepository.findByProdName(prodName);
	}

	@Override
	public List<Product> findProducts() {
		return productRepository.findAll();
	}

}
