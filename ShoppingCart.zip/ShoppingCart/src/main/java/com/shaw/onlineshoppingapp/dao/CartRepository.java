package com.shaw.onlineshoppingapp.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.shaw.onlineshoppingapp.dto.ProductInfo;

@Repository
public interface CartRepository {

	public List<ProductInfo> getAllProducts();
	 
}
