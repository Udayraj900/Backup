package com.shaw.onlineshoppingapp.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name = "Product")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(
		  name="Product_Category", 
		  discriminatorType=DiscriminatorType.STRING
		  )
public class Product implements Serializable {
 

	

	private static final long serialVersionUID = 5680942233433432415L;

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "product_id")
    private Integer productId;
 
    @Column(name = "prod_name", length = 255, nullable = false)
    private String prodName;
 
    @Column(name = "Price", nullable = false)
    private double price;
 
    public Product() {
    }
    
    public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getName() {
        return prodName;
    }
 
    public void setName(String name) {
        this.prodName = name;
    }
 
    public double getPrice() {
        return price;
    }
 
    public void setPrice(double price) {
        this.price = price;
    }
    @Override
	public String toString() {
		return "Product [productId=" + productId + ", prodName=" + prodName + ", price=" + price  + "]";
	}
   
 
}
