package com.mindtree.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.mindtree.dateformat.CustomDateFormats;
import com.mindtree.vo.BookingVO;

@Component
public class BookingValidator implements Validator {

	@Override
	public boolean supports(Class<?> paramClass) {
		return BookingVO.class.equals(paramClass);
	}

	@Override
	public void validate(Object obj, Errors errors) {

		
		CustomDateFormats format=new CustomDateFormats(); 
		BookingVO booking = (BookingVO) obj;
		
		if (booking.getCheckindate() != "" && booking.getCheckindate() !=null)
			if (!format.isValidDate(booking.getCheckindate()))
				errors.rejectValue("checkindate", "checkin.invalid");
		if (booking.getCheckoutdate() != "" && booking.getCheckoutdate() !=null)
			if (!format.isValidDate(booking.getCheckoutdate()))
				errors.rejectValue("checkoutdate", "checkout.invalid");	
		if (booking.getCheckindate() == null || booking.getCheckindate() =="") {
			errors.rejectValue("checkindate","checkin.required");
		}
		if (booking.getCheckoutdate() == null || booking.getCheckoutdate()=="") {
			errors.rejectValue("checkoutdate", "checkout.required");
		}
	
	}
}
