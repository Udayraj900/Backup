package com.mindtree.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.mindtree.vo.BookingVO;

@Component
public class LoginValidator implements Validator {
 
    //which objects can be validated by this validator
    @Override
    public boolean supports(Class<?> paramClass) {
        return BookingVO.class.equals(paramClass);
    }
 
    @Override
    public void validate(Object obj, Errors errors) {
        
         
       /* BookingVO booking = (BookingVO) obj;
        if(booking.getUser().geteMail()==null || booking.getUser().geteMail()==""){
        	errors.rejectValue("user.eMail","user.eMail.required");
        }*/
    	ValidationUtils.rejectIfEmptyOrWhitespace(errors, "user.password", "error.user.password", "Password is mandatory");
    	ValidationUtils.rejectIfEmptyOrWhitespace(errors, "user.eMail", "error.user.eMail", "E-Mail is mandatory");         
        
        
    }
}