package com.mindtree.dateformat;

import java.text.SimpleDateFormat;
import java.util.Date;

public class CustomDateFormats {

	/**
	 * @param String
	 * @return Date
	 */
	public Date DateFormat1(String date)
	{
	SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
	    try {
		return formatter.parse(date);
		} catch (Exception e) {

		}
		return null;
	}
	
	/**
	 * @param String
	 * @return Date
	 */
	public String DateFormat2(Date date) {
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		return formatter.format(date);
	}
	
    /**
     * @param String
     * @return Date
     */
    public String DateFormat3(Date date) {
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		return formatter.format(date);
	}
	
	/**
	 * @param String
	 * @return boolean
	 */
	public boolean isValidDate(String date)
	{
		
		if(date.length()!=10)
			return false;
		if(date.length()==10)
		{
			if(!date.substring(2,3).equals("-") || !date.substring(5,6).equals("-"))
				return false;
			
			int day = 0;
			int month = 0;
			int year = 0;
			try{
			   day=Integer.parseInt(date.substring(0,2));
			   month=Integer.parseInt(date.substring(3,5));
			   year=Integer.parseInt(date.substring(6,10));
			}catch(Exception e) {
				return false;
				}
			
			if(month>12 || day>31 || month<1 || day<1 || year/1000==0)
		      return false;
		    
	        if(year %400 == 0 || (year % 100 != 0 && year % 4 == 0))
	           if(month==2 && day>=29)
	        		return false;
	        if (  (month == 1 || month==3 || month==5 || month==7 || month==8 || month==10 || month==12) && day>31)
                return false;
            if (  (month == 4 || month==6 || month==9 || month==11) && day>30)
                return false;
		}
		return true;
	}
	
}
