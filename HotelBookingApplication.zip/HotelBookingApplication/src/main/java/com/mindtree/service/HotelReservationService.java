package com.mindtree.service;

import java.util.ArrayList;
import java.util.List;

import com.mindtree.entity.Hotel;
import com.mindtree.entity.Reservation;
import com.mindtree.entity.User;
import com.mindtree.vo.BookingVO;
import com.mindtree.vo.HotelVO;

public interface HotelReservationService {

	ArrayList<Hotel> getHotels(HotelVO hotelVO);
	User isValidAccount(User user);
	void PlaceReservation(BookingVO booking);
	List<Reservation> getAllReservations(User user);
	ArrayList<Hotel> getHotelCity(Hotel hotel);
	ArrayList<Hotel> getHotelName(String city);
	ArrayList<Hotel> getLeastHotelName(String city);
	ArrayList<Hotel> getLeastCostHotels(HotelVO hotelVO);
	void saveBooking(BookingVO bookingDetails);
}