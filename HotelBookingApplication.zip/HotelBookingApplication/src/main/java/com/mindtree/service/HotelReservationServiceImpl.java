package com.mindtree.service;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dao.HotelReservation;
import com.mindtree.entity.Hotel;
import com.mindtree.entity.Reservation;
import com.mindtree.entity.User;
import com.mindtree.vo.BookingVO;
import com.mindtree.vo.HotelVO;

@Service
public class HotelReservationServiceImpl implements HotelReservationService {

	  @Autowired
	  HotelReservation hotelReservationDao;

	public void setHotelReservationDao(HotelReservation hotelReservationDao) {
		this.hotelReservationDao = hotelReservationDao;
	}

	@Override
	public ArrayList<Hotel> getHotels(HotelVO hotelVO) {
		
		return hotelReservationDao.getHotels(hotelVO);
		
	}
	
	@Override
	public ArrayList<Hotel> getHotelCity(Hotel hotel) {
			return hotelReservationDao.getHotelCity(hotel);
	}

	@Override
	public User isValidAccount(User user) {
		
		return hotelReservationDao.isValidAccount(user);
	}

	@Override
	public void PlaceReservation(BookingVO booking) {
		
		hotelReservationDao.PlaceReservation(booking);
	}

	@Override
	public List<Reservation> getAllReservations(User user) {
		
		return hotelReservationDao.getAllReservations(user);
	}


	public ArrayList<Hotel> getLeastCostHotels(HotelVO hotelVO) {
		return hotelReservationDao.getLeastCostHotels(hotelVO);
	}

	public ArrayList<Hotel> getHotelName(String city){
		return hotelReservationDao.getHotelName(city);
	}

	@Override
	public ArrayList<Hotel> getLeastHotelName(String city) {
		return hotelReservationDao.getLeastHotelName(city);
	}

	@Override
	public void saveBooking(BookingVO bookingDetails) {
		hotelReservationDao.saveBooking(bookingDetails);
		
	}

}
