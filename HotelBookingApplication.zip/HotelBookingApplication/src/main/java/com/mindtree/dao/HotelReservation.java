package com.mindtree.dao;

import java.util.ArrayList; 
import java.util.List;

import com.mindtree.entity.Hotel;
import com.mindtree.entity.Reservation;
import com.mindtree.entity.User;
import com.mindtree.vo.BookingVO;
import com.mindtree.vo.HotelVO;

/**
 * @author M1036091
 *
 */
public interface HotelReservation {

	
	/**
	 * @param hotelVO
	 * @return ArrayList<Hotel>
	 */
	ArrayList<Hotel> getHotels(HotelVO hotelVO);

	/**
	 * @param user
	 * @return boolean
	 */
	User isValidAccount(User user);

	
	ArrayList<Hotel> getHotelCity(Hotel hotel);
	
	/**
	 * @param booking
	 */
	void PlaceReservation(BookingVO booking);

	/**
	 * @param user
	 * @return List<Reservation>
	 */
	List<Reservation> getAllReservations(User user);
	

	
	ArrayList<Hotel> getLeastCostHotels(HotelVO hotelVO);
	
	ArrayList<Hotel> getHotelName(String city);

	ArrayList<Hotel> getLeastHotelName(String city);

	void saveBooking(BookingVO bookingDetails);

}