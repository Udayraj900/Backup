package com.mindtree.dao;

import java.util.ArrayList; 
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.entity.Hotel;
import com.mindtree.entity.Reservation;
import com.mindtree.entity.User;
import com.mindtree.vo.BookingVO;
import com.mindtree.vo.HotelVO;

/**
 * @author M1036091
 *
 */
@Transactional  
@Repository  
public class HotelReservationDaoImpl implements HotelReservation{
	
	  @Autowired  
	  SessionFactory sessionFactory;  
	  
	/**
	 * @param sessionFactory
	 */
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	/**
	 * @param reservation
	 */
	@SuppressWarnings("unused")
	public void save(Reservation reservation)  
	  {  
	    Session session = sessionFactory.getCurrentSession();  
	     
	   
	  }
	
    /* (non-Javadoc)
	 * @see com.mindtree.dao.HotelReservation#getHotels(com.mindtree.vo.HotelVO)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public ArrayList<Hotel> getHotels(HotelVO hotelVO) {

		Session session = sessionFactory.getCurrentSession();  
		String hql="from Hotel h where h.hotelName like '"+hotelVO.getHotelName()+"%'";
		List<Hotel> hotelList=session.createQuery(hql).list();
		return (ArrayList<Hotel>) hotelList;
		
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public ArrayList<Hotel> getHotelCity(Hotel hotel) {
    Session session = sessionFactory.getCurrentSession();  
	String hql = "select distinct city from Hotel";
	List<Hotel> hotelCity = session.createQuery(hql).list();
	System.out.println(hotelCity);
	return (ArrayList<Hotel>) hotelCity;
	}
	

	/* (non-Javadoc)
	 * @see com.mindtree.dao.HotelReservation#isValidAccount(com.mindtree.entity.User)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public User isValidAccount(User user) 
	{
		Session session = sessionFactory.getCurrentSession();  
		String hql="from User";
		List<User> UserList=session.createQuery(hql).list();
		for(User user1:UserList)
		  if(user.geteMail().equals(user1.geteMail()) && user.getPassword().equals(user1.getPassword()))
				return user1;
		return null;
	}

	/* (non-Javadoc)
	 * @see com.mindtree.dao.HotelReservation#PlaceReservation(com.mindtree.vo.BookingVO)
	 */
	@Override
	public void PlaceReservation(BookingVO booking) {
		
		Reservation reservation=new Reservation(booking.getUser(),booking.getHotel(),booking.getCheckin(),booking.getCheckout(),booking.getNoOfRooms());
		Session session = sessionFactory.getCurrentSession();
		session.save(reservation); 
	}

	/* (non-Javadoc)
	 * @see com.mindtree.dao.HotelReservation#getAllReservations(com.mindtree.entity.User)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<Reservation> getAllReservations(User user) {
		
		Session session = sessionFactory.getCurrentSession();  
		String hql="from Reservation r where r.user.id="+user.getId();
		List<Reservation> ReservationList=session.createQuery(hql).list();
		return ReservationList;
	}

	@Override
	@SuppressWarnings("unchecked")
	public ArrayList<Hotel> getLeastCostHotels(HotelVO hotelVO) {
		Session session = sessionFactory.getCurrentSession();  
		String hql = "select distinct city from Hotel";
		List<Hotel> LeastCostHotels = session.createQuery(hql).list();
		System.out.println(LeastCostHotels);
		return (ArrayList<Hotel>) LeastCostHotels;
	}

	@Override
	@SuppressWarnings("unchecked")
	public ArrayList<Hotel> getHotelName(String city) {
		 Session session = sessionFactory.getCurrentSession();  
			String hql = "from Hotel h where h.city='"+city+"'";
			List<Hotel> hotelName = session.createQuery(hql).list();
			System.out.println(hotelName+"in dao");
			return (ArrayList<Hotel>) hotelName;
			
	}

	@Override
	@SuppressWarnings("unchecked")
	public ArrayList<Hotel> getLeastHotelName(String city) {
		 Session session = sessionFactory.getCurrentSession();  
			String hql = "from Hotel h where h.city='"+city+"' order by cost asc";
			List<Hotel> hotelLeastName = session.createQuery(hql).list();
			System.out.println(hotelLeastName+"in dao");
			return (ArrayList<Hotel>) hotelLeastName;
	}

	@Override
	public void saveBooking(BookingVO bookingDetails) {
		Reservation reservation=new Reservation(bookingDetails.getUser(),bookingDetails.getHotel(),bookingDetails.getCheckin(),bookingDetails.getCheckout(),bookingDetails.getNoOfRooms());
		Session session = sessionFactory.getCurrentSession();
		session.save(reservation); 
		
	}
	public ArrayList<Hotel> getLeastHotelNameNew(String city) {
	
		 Session session = sessionFactory.getCurrentSession(); 
			Criteria criteria = session.createCriteria(Hotel.class);
			criteria.add(Restrictions.eq("city", city));
			criteria.addOrder(Order.asc("cost"));
			//String hql = "from Hotel h where h.city='"+city+"' order by cost asc";
			//List<Hotel> hotelLeastName = session.createQuery(hql).list();
			@SuppressWarnings("unchecked")
			List<Hotel> hotelLeastName = criteria.list();
			System.out.println(hotelLeastName+"in dao");
			return (ArrayList<Hotel>) hotelLeastName;
	}

	
}
