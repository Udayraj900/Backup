package com.mindtree.vo;

import java.util.Date;
import com.mindtree.entity.Hotel;
import com.mindtree.entity.User;
import com.mindtree.dateformat.CustomDateFormats;

public class BookingVO {
	
	
	private int hotelId;
    private Hotel hotel;
	private User user;
	private Date checkin;
	private Date checkout;
	private String checkindate=null;
	private String checkoutdate=null;
	private int noOfRooms;
	 
	CustomDateFormats format=new CustomDateFormats();
	
	public String getCheckindate() {
		return checkindate;
	}

	public void setCheckindate(String checkindate) {
		this.checkin = format.DateFormat1(checkindate);
		this.checkindate=checkindate;
	}

	public String getCheckoutdate() {
		return checkoutdate;
	}

	public void setCheckoutdate(String checkoutdate) {
		this.checkout= format.DateFormat1(checkoutdate);
		this.checkoutdate=checkoutdate;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Date getCheckin() {
		return checkin;
	}

	public void setCheckin(Date checkin) {
		this.checkin = checkin;
	}

	public Date getCheckout() {
		return checkout;
	}

	public void setCheckout(Date checkout) {
		this.checkout = checkout;
	}

	public int getNoOfRooms() {
		return noOfRooms;
	}

	public void setNoOfRooms(int noOfRooms) {
		this.noOfRooms = noOfRooms;
	}

}
