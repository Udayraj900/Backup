package com.mindtree.controller;

import java.io.IOException; 
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.mindtree.entity.Hotel;
import com.mindtree.entity.Reservation;
import com.mindtree.entity.User;
import com.mindtree.service.HotelReservationService;
import com.mindtree.validator.BookingValidator;
import com.mindtree.validator.LoginValidator;
import com.mindtree.vo.BookingVO;
import com.mindtree.vo.HotelVO;

@Controller
public class HotelReservationController {

	@Autowired
	HotelReservationService hotelReservationService;

	@Autowired
	LoginValidator loginValidator;

	@Autowired
	BookingValidator bookingValidator;

	static Logger log = Logger.getLogger(HotelReservationController.class.getName());

	Hotel hotel = null;
	User user = null;

	public void setHotelReservationService(HotelReservationService hotelReservationService) {
		this.hotelReservationService = hotelReservationService;
	}

	/**
	 * @param model
	 * @return to Search.jsp
	 * @throws IOException
	 * @throws ServletException
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/SearchHotels.view")
	public String SearchHotels(Model model) throws IOException, ServletException {

		HotelVO hotelVO = new HotelVO();
		model.addAttribute("hotelVO", hotelVO);
		return "Search";

	}

	@RequestMapping(method = RequestMethod.GET, value = "/BookRoom.view")
	public String BookRooms(Model model) throws IOException, ServletException {
		Hotel hotel = new Hotel();
		model.addAttribute("hotelCityList", hotelReservationService.getHotelCity(hotel));
		System.out.println(hotelReservationService.getHotelCity(hotel));
		return "BookRoom";
	}

	/**
	 * @param hotelVO
	 * @param model
	 * @return to DisplayHotels
	 * @throws IOException
	 * @throws ServletException
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/SearchHotels.view")
	public String SearchHotels(@ModelAttribute("hotelVO") HotelVO hotelVO, Model model)
			throws IOException, ServletException {

		log.debug("Searching Hotels...");
		model.addAttribute("hotelsList", hotelReservationService.getHotels(hotelVO));
		Booking(model);
		return "DisplayHotels";

	}

	/**
	 * @param model
	 * @return to DisplayHotels.jsp
	 * @throws IOException
	 * @throws ServletException
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/Booking.view")
	public String Booking(Model model) throws IOException, ServletException {

		BookingVO booking = new BookingVO();
		model.addAttribute("booking", booking);
		return "DisplayHotels";

	}

	/**
	 * @param booking
	 * @param model
	 * @return to Login.jsp
	 * @throws IOException
	 * @throws ServletException
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/Booking.view")
	public String Booking(@ModelAttribute("booking") BookingVO booking, Model model)
			throws IOException, ServletException {
		log.debug("Creating Login Object...");
		Login(model, booking);
		return "Login";

	}

	/**
	 * @param model
	 * @param booking
	 * @return to Login.jsp
	 * @throws IOException
	 * @throws ServletException
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/Login.view")
	public String Login(Model model, BookingVO booking) throws IOException, ServletException {

		hotel = booking.getHotel();
		model.addAttribute("booking", booking);
		return "Login";

	}

	/**
	 * @param booking
	 * @param bindingResult
	 * @param model
	 * @return to BookHotel.jsp/Login.jsp
	 * @throws IOException
	 * @throws ServletException
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/Login.view")
	public String Login(@ModelAttribute("booking") BookingVO booking, BindingResult bindingResult, Model model)
			throws IOException, ServletException {

		loginValidator.validate(booking, bindingResult);
		if (bindingResult.hasErrors()) {
			return "Login";
		}

		booking.setHotel(hotel);
		user = hotelReservationService.isValidAccount(booking.getUser());
		if (user != null) {
			booking.setUser(user);
			PlaceReservation(model, booking);
			return "BookHotel";
		} else {
			model.addAttribute("message", "Invalid Credentials !");
			return "Login";
		}

	}

	/**
	 * @param model
	 * @param booking
	 * @return BookHotel.jsp
	 * @throws IOException
	 * @throws ServletException
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/PlaceReservation.view")
	public String PlaceReservation(Model model, BookingVO booking) throws IOException, ServletException {

		model.addAttribute("reservation", booking);
		return "BookHotel";
	}

	/**
	 * @param booking
	 * @param bindingResult
	 * @param model
	 * @return to BookingDetails.jsp
	 * @throws ServletException
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/PlaceReservation.view")
	public String PlaceReservation(@ModelAttribute("reservation") BookingVO booking, BindingResult bindingResult,
			Model model) throws ServletException {

		log.debug("Booking reservation .....");
		booking.setHotel(hotel);
		booking.setUser(user);

		bookingValidator.validate(booking, bindingResult);
		if (bindingResult.hasErrors()) {
			return "BookHotel";
		}

		hotelReservationService.PlaceReservation(booking);
		List<Reservation> reservationLists = hotelReservationService.getAllReservations(booking.getUser());
		model.addAttribute("reservationLists", reservationLists);
		return "BookingDetails";

	}

	@RequestMapping(method = RequestMethod.GET, value = "/LeastCostHotels.view")
	public String LeastCostHotels(Model model) throws IOException, ServletException {
		HotelVO hotelVO = new HotelVO();
		model.addAttribute("leastCostHotels", hotelReservationService.getLeastCostHotels(hotelVO));
		return "LeastCostCities";

	}

	@RequestMapping(method = RequestMethod.GET, value = "/register.view")
	public String register(Model model) throws IOException, ServletException {
		return "register";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/backtologin.view")
	public String backToLogin(Model model) throws IOException, ServletException {
		return "Login";
		
	}	
	
	@RequestMapping(method = RequestMethod.GET, value = "/getHotelName")
	public void getHotelName(@RequestParam("city") String city,HttpServletResponse response)
	{   
		ArrayList<Hotel> myItem = hotelReservationService.getHotelName(city);
		System.out.println("Hello");
		System.out.println(myItem+"in controller");
		Gson gson=new Gson();
		String json=gson.toJson(myItem);
		System.out.println(myItem);
		PrintWriter pw=null;
		try {
			pw = response.getWriter();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		pw.write(json);
	
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/getLeastHotels")
	public void getLeastHotels(@RequestParam("city") String city,HttpServletResponse response)
	{   
		ArrayList<Hotel> leastHotels = hotelReservationService.getLeastHotelName(city);
		System.out.println("Hello");
		System.out.println(leastHotels +"in controller");
		Gson gson=new Gson();
		String jsonObject=gson.toJson(leastHotels);
		System.out.println(leastHotels);
		PrintWriter pw=null;
		try {
			pw = response.getWriter();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		pw.write(jsonObject);
	
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/logout.view")
	public String logOut(Model model) throws IOException, ServletException {
		return "index";
		
	}	
	
	@RequestMapping(method = RequestMethod.POST, value ="/saveBooking.view")
    public ModelAndView saveBookingDetails(HttpServletRequest request, @ModelAttribute("bookingDetails") BookingVO bookingDetails,BindingResult result)
    {
		bookingDetails.setHotel(hotel);
		bookingDetails.setUser(user);
           if(result.hasErrors())
           {
                  return new ModelAndView("BookRoom");
           }
           else
           {
          
          hotelReservationService.saveBooking(bookingDetails);
           ModelAndView modelview= new ModelAndView();
           String message="Great!!!! Your booking has been done";
           modelview.addObject("message", message);
           modelview.setViewName("index");
         return modelview;
    }
	
    }
}
