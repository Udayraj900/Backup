package com.mindtree.entity;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="reservation_details")
public class Reservation 
{
	@Id
	@Column(name="reservation_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int confirmationId;
	
    @Column(name="check_in")
    private Date checkinDate;
    
    @Column(name="check_out")
    private Date checkoutDate;
    
    @Column(name="no_of_rooms")
    private int noOfRooms;
    
   
    @ManyToOne(cascade=CascadeType.ALL)  
	@JoinColumn(name="user_id",referencedColumnName="user_id",updatable=false)
    private User user;
    
    @ManyToOne(cascade=CascadeType.ALL)  
	@JoinColumn(name="hotel_id",referencedColumnName="hotel_id")
    private Hotel hotel;
    
    public Reservation(){}
	
	public Reservation(User user, Hotel hotel,Date checkinDate, Date checkoutDate, int noOfRooms) {
		
		this.checkinDate = checkinDate;
		this.checkoutDate = checkoutDate;
		this.user = user;
		this.hotel = hotel;
		this.noOfRooms = noOfRooms;
	}
	public Hotel getHotel() {
		return hotel;
	}
	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public int getConfirmationId() {
		return confirmationId;
	}
	public void setConfirmationId(int confirmationId) {
		this.confirmationId = confirmationId;
	}

	public Date getCheckinDate() {
		return checkinDate;
	}
	public void setCheckinDate(Date checkinDate){
		this.checkinDate =checkinDate;
	}
	public Date getCheckoutDate() {
		return checkoutDate;
	}
	public void setCheckoutDate(Date checkoutDate) {
		this.checkoutDate =checkoutDate;
	}
    
	public String myFormat(Date datetime) {
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		System.out.println(datetime);
		return formatter.format(datetime);
	}
	
	public String getCheckin() {
		return myFormat(checkinDate);
	}

	public String getCheckout() {
		return myFormat(checkoutDate);
	}
    
    
}
