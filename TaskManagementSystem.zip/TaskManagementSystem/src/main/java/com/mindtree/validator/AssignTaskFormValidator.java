/**
 * 
 */
package com.mindtree.validator;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.mindtree.entity.AssignTask;
import com.mindtree.vo.AssignTaskVo;

/**
 * @author RShaw
 *
 */
@Component
public class AssignTaskFormValidator implements Validator {

	static Logger logger = Logger.getLogger(AssignTaskFormValidator.class.getName());
	
	/* (non-Javadoc)
	 * @see org.springframework.validation.Validator#supports(java.lang.Class)
	 */
	@Override
	public boolean supports(Class<?> clazz) {
		return AssignTask.class.isAssignableFrom(clazz);
	}

	/* (non-Javadoc)
	 * @see org.springframework.validation.Validator#validate(java.lang.Object, org.springframework.validation.Errors)
	 */
	@SuppressWarnings("unused")
	@Override
	public void validate(Object target, Errors error) {
		
		AssignTaskVo assignTask = (AssignTaskVo) target;
		
		ValidationUtils.rejectIfEmptyOrWhitespace(error, "project.projectId", "error.project.required");
		
		ValidationUtils.rejectIfEmptyOrWhitespace(error, "taskDescription", "error.taskDescription.required");
		
		ValidationUtils.rejectIfEmptyOrWhitespace(error, "taskStartDate", "error.taskStartDate.required");
		
		ValidationUtils.rejectIfEmptyOrWhitespace(error, "taskEndDate", "error.taskEndDate.required");
		
		ValidationUtils.rejectIfEmptyOrWhitespace(error, "employees", "error.employees.required");
	}

}
