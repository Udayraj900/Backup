package com.mindtree.dao;

import java.util.List;
import java.util.Set;

import com.mindtree.entity.AssignTask;
import com.mindtree.entity.Employee;
import com.mindtree.entity.Project;
import com.mindtree.exception.FetchException;
import com.mindtree.exception.PersistenceException;
import com.mindtree.vo.AssignTaskVo;

public interface AssignTaskDao {

	public List<Project> getAllProjects() throws FetchException;

	public List<Employee> getEmployeesByProject(Integer projectId) throws FetchException;

	public void saveAssignTask(AssignTaskVo assignTaskVo) throws PersistenceException, FetchException;

	public List<AssignTask> getAllTasks() throws FetchException;

	public List<AssignTask> getTasksByProject(Integer projectId) throws FetchException;

	public Project getProjectById(Integer projectId) throws FetchException;

	public Set<Employee> getEmployeeListByTask(Integer taskId) throws FetchException;

	public Employee getEmployeesByMId(String empId) throws FetchException;
}
