package com.mindtree.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.entity.AssignTask;
import com.mindtree.entity.Employee;
import com.mindtree.entity.Project;
import com.mindtree.exception.FetchException;
import com.mindtree.exception.PersistenceException;
import com.mindtree.vo.AssignTaskVo;

/*
 * @author M1023322
 */
		
		

@Repository("assignTaskDao")
public class AssignTaskDaoImpl implements AssignTaskDao {

	
	private static Logger logger = Logger.getLogger(AssignTaskDaoImpl.class);

	
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Autowired
	public AssignTaskDaoImpl(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Project> getAllProjects() throws FetchException{
		Session session = sessionFactory.getCurrentSession();
		List<Project> listProjects = session.createQuery("from Project").list();
		logger.info("listProjects::"+listProjects);
        return listProjects;
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public List<Employee> getEmployeesByProject(Integer projectId) throws FetchException{
		Session session = sessionFactory.getCurrentSession();
		String hql="from Employee where project.projectId = "+projectId;
		List<Employee> empList = (List<Employee>) session.createQuery(hql).list();
		logger.info(empList);
		return empList;
	}

	@Override
	public Employee getEmployeesByMId(String mId) throws FetchException{
		Session session = sessionFactory.getCurrentSession();
		Employee emp =  (Employee) session.get(Employee.class, mId);
		logger.info(emp);
		return emp;
	}
	@Override
	public void saveAssignTask(AssignTaskVo assignTaskVo) throws PersistenceException, FetchException {
		System.out.println("inside saving task Dao  "+ assignTaskVo);
		AssignTask task = new AssignTask();
		task.setTaskDescription(assignTaskVo.getTaskDescription());
		task.setTaskStartDate(assignTaskVo.getTaskStartDate());
		task.setTaskEndDate(assignTaskVo.getTaskEndDate());
		task.setProject(assignTaskVo.getProject());
		Set<Employee> employees = new HashSet<Employee>();
		
		for(String mId : assignTaskVo.getEmployees()) {
			Employee employee = new Employee();
			employee = getEmployeesByMId(mId);
			employees.add(employee);
		}
		task.setEmployees(employees);
		
		Session session = sessionFactory.getCurrentSession();
		session.save(task);	
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AssignTask> getAllTasks() throws FetchException{
		Session session = sessionFactory.getCurrentSession();
		List<AssignTask> taskList = session.createQuery("from AssignTask").list();
        return taskList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AssignTask> getTasksByProject(Integer projectId) throws FetchException{
		
			Session session = sessionFactory.getCurrentSession();
			String hql="from AssignTask where project.projectId = "+projectId;
			List<AssignTask> taskList = (List<AssignTask>) session.createQuery(hql).list();
			return taskList;
		
	}

	@Override
	public Project getProjectById(Integer projectId) throws FetchException{
		Session session = sessionFactory.getCurrentSession();
		Project project =  (Project) session.get(Project.class, projectId);
		return project;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Set<Employee> getEmployeeListByTask(Integer taskId) throws FetchException{
		Session session = sessionFactory.getCurrentSession();	
		String hql="from AssignTask where taskId = "+taskId;
		List<AssignTask> taskList = (List<AssignTask>) session.createQuery(hql).list();
		Set<Employee> empList = new HashSet<Employee>();
		for (AssignTask assignTask : taskList) {
			for(Employee employee2 : assignTask.getEmployees()) {
				empList.add(employee2);
			}
		}
		return empList;
	}
}
