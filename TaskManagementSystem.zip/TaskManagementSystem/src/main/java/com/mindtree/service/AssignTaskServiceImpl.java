package com.mindtree.service;

import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.AssignTaskDao;
import com.mindtree.entity.AssignTask;
import com.mindtree.entity.Employee;
import com.mindtree.entity.Project;
import com.mindtree.exception.FetchException;
import com.mindtree.exception.PersistenceException;
import com.mindtree.exception.ServiceException;
import com.mindtree.vo.AssignTaskVo;
@Transactional
@Service
public class AssignTaskServiceImpl implements AssignTaskService {

	@SuppressWarnings("unused")
	private static Logger logger = Logger.getLogger(AssignTaskServiceImpl.class);

	@Autowired
	private AssignTaskDao assignTaskDao;
	
	public AssignTaskServiceImpl() {
		
	}
	
	public AssignTaskServiceImpl(AssignTaskDao assignTaskDao) {
		this.assignTaskDao = assignTaskDao;
	}

	@Override
	public List<Project> getAllProjects() throws ServiceException, FetchException{
		return assignTaskDao.getAllProjects();
	}

	@Override
	public List<Employee> getEmployeesByProject(Integer projectId) throws ServiceException, FetchException{
		return assignTaskDao.getEmployeesByProject(projectId);
	}

	@Override
	public void saveAssignTask(AssignTaskVo assignTaskVo) throws ServiceException, PersistenceException, FetchException {
		assignTaskDao.saveAssignTask(assignTaskVo);
		
	}

	@Override
	public List<AssignTask> getAllTasks() throws ServiceException, FetchException{
		return assignTaskDao.getAllTasks();
	}

	@Override
	public List<AssignTask> getTasksByProject(Integer projectId) throws ServiceException, FetchException{	
		return assignTaskDao.getTasksByProject(projectId);
	}

	@Override
	public Project getProjectById(Integer projectId) throws FetchException {
		return assignTaskDao.getProjectById(projectId);
	}

	@Override
	public Set<Employee> getEmployeeListByTask(Integer taskId) throws FetchException  {
		return assignTaskDao.getEmployeeListByTask(taskId);
	}

	@Override
	public Employee getEmployeesByMId(String empId) throws ServiceException, FetchException {
		return assignTaskDao.getEmployeesByMId(empId);
	}

	
	
}
