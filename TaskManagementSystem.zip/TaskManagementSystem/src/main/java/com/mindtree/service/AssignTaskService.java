package com.mindtree.service;

import java.util.List;
import java.util.Set;

import com.mindtree.entity.AssignTask;
import com.mindtree.entity.Employee;
import com.mindtree.entity.Project;
import com.mindtree.exception.FetchException;
import com.mindtree.exception.PersistenceException;
import com.mindtree.exception.ServiceException;
import com.mindtree.vo.AssignTaskVo;

public interface AssignTaskService {

	public List<Project> getAllProjects() throws ServiceException, FetchException;

	public List<Employee> getEmployeesByProject(Integer projectId) throws ServiceException, FetchException;

	public void saveAssignTask(AssignTaskVo assignTaskVo) throws ServiceException, PersistenceException, FetchException;

	public List<AssignTask> getAllTasks() throws ServiceException, FetchException;

	public List<AssignTask> getTasksByProject(Integer projectId) throws ServiceException, FetchException;

	public Project getProjectById(Integer projectId) throws ServiceException, FetchException;

	public Set<Employee> getEmployeeListByTask(Integer taskId) throws ServiceException, FetchException ;

	public Employee getEmployeesByMId(String empId) throws ServiceException, FetchException;
}
