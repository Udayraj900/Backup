package com.mindtree.controller;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

	static Logger logger = Logger.getLogger(HomeController.class.getName());
	
	@RequestMapping(value = "/home.view")
	public String goToHome() {
		return "home";
	}
}
