package com.mindtree.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mindtree.entity.AssignTask;
import com.mindtree.entity.Employee;
import com.mindtree.entity.Project;
import com.mindtree.exception.FetchException;
import com.mindtree.exception.PersistenceException;
import com.mindtree.exception.ServiceException;
import com.mindtree.service.AssignTaskService;
import com.mindtree.validator.AssignTaskFormValidator;
import com.mindtree.vo.AssignTaskVo;
import com.mindtree.vo.TaskViewVo;

@Controller
public class AssignTasksController {

	@SuppressWarnings("unused")
	private static Logger logger = Logger.getLogger(AssignTasksController.class);

	private AssignTaskService assignTaskService;

	@Autowired
	AssignTaskFormValidator assignTaskValidator;

	public AssignTasksController() {

	}

	@Autowired
	public AssignTasksController(AssignTaskService assignTaskService) {
		this.assignTaskService = assignTaskService;

	}

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}

	public List<Project> getAllProjects() throws ServiceException, FetchException{
		return assignTaskService.getAllProjects();
	}

	@RequestMapping(value = "/loadEmployeesList", method = RequestMethod.GET)
	@ResponseBody
	public List<Employee> getEmployeesByProject(Integer projectId) throws ServiceException, FetchException{
		return assignTaskService.getEmployeesByProject(projectId);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/AssignTaskForm")
	public String getAssignTasksForm(Model model) throws ServiceException, FetchException {
		model.addAttribute("assignTask", new AssignTaskVo());
		model.addAttribute("projectList", getAllProjects());
		return "AssignTaskForm";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/saveTask")
	public String saveTask(@ModelAttribute("assignTask") AssignTaskVo assignTaskVo, BindingResult result, Locale locale,
			Model model) throws ServiceException, PersistenceException, FetchException{
		String page = "home";
		assignTaskValidator.validate(assignTaskVo, result);
		if (result.hasErrors()) {
			if(assignTaskVo.getProject()!=null) {
			model.addAttribute("empList", getEmployeesByProject(assignTaskVo.getProject().getProjectId()));
			}
			model.addAttribute("projectList", getAllProjects());
			return "AssignTaskForm";
		}
		
		
		assignTaskService.saveAssignTask(assignTaskVo);
		model.addAttribute("msg", "Task successfully assigned.");

		return page;

	}

	@RequestMapping(value = "/taskViewPage", method = RequestMethod.GET)
	public String getTaskViewPage(Model model) throws ServiceException, FetchException{
		model.addAttribute("project", new Project());
		model.addAttribute("projectList", getAllProjects());
		return "taskViewPage";

	}

	@RequestMapping(value = "/getTasks", method = RequestMethod.GET)
	@ResponseBody
	public Map<String, List<TaskViewVo>> getTasks(Integer projectId) throws ServiceException, FetchException{
		System.out.println("In Controller For Employees for project id" + projectId);
		List<AssignTask> assignTaskList = new ArrayList<AssignTask>();
		Map<String, List<TaskViewVo>> tasksMap = new HashMap<String, List<TaskViewVo>>();
		if (projectId == 0) {
			assignTaskList = assignTaskService.getAllTasks();
			List<Project> projects = getAllProjects();
			for (Project project : projects) {
				List<TaskViewVo> taskByProject = new ArrayList<TaskViewVo>();
				for (AssignTask assignTask1 : assignTaskList) {
					Set<Employee> empListByTask = new HashSet<Employee>();
					if (project.getProjectId().equals(assignTask1.getProject().getProjectId())) {
						empListByTask = assignTaskService.getEmployeeListByTask(assignTask1.getTaskId());
						TaskViewVo viewVo = new TaskViewVo(assignTask1.getTaskId(), assignTask1.getTaskDescription(),
								new SimpleDateFormat("dd-MM-yyyy").format(assignTask1.getTaskStartDate()),
								new SimpleDateFormat("dd-MM-yyyy").format(assignTask1.getTaskEndDate()));

						viewVo.setEmployess(empListByTask);
						taskByProject.add(viewVo);
						System.out.println("empllist  ::  " + empListByTask);
					}
				}
				if (taskByProject != null)
					tasksMap.put(project.getProjectName(), taskByProject);
			}

		} else {
			List<TaskViewVo> taskByProject = new ArrayList<TaskViewVo>();
			assignTaskList = assignTaskService.getTasksByProject(projectId);
			Project project = assignTaskService.getProjectById(projectId);
			for (AssignTask assignTask1 : assignTaskList) {
				Set<Employee> empListByTask = new HashSet<Employee>();
				if (project.getProjectId().equals(assignTask1.getProject().getProjectId())) {
					empListByTask = assignTaskService.getEmployeeListByTask(assignTask1.getTaskId());
					TaskViewVo viewVo = new TaskViewVo(assignTask1.getTaskId(), assignTask1.getTaskDescription(),
							new SimpleDateFormat("dd-MM-yyyy").format(assignTask1.getTaskStartDate()),
							new SimpleDateFormat("dd-MM-yyyy").format(assignTask1.getTaskEndDate()));

					viewVo.setEmployess(empListByTask);
					taskByProject.add(viewVo);
					System.out.println("empllist  ::  " + empListByTask);
				}
			}
			tasksMap.put(project.getProjectName(), taskByProject);
		}
		return tasksMap;
	}
}