/**
 * 
 */
package com.mindtree.vo;

import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;

import com.mindtree.entity.Project;

/**
 * @author RShaw
 *
 */
public class AssignTaskVo {

	static Logger logger = Logger.getLogger(AssignTaskVo.class.getName());
	
	private Project project;
	private Integer taskId;
	private String taskDescription;
	private Date taskStartDate;
	private Date taskEndDate;
	private List<String> employees;
	
	public Project getProject() {
		return project;
	}
	public void setProject(Project project) {
		this.project = project;
	}
	public Integer getTaskId() {
		return taskId;
	}
	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}
	public String getTaskDescription() {
		return taskDescription;
	}
	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}
	public Date getTaskStartDate() {
		return taskStartDate;
	}
	public void setTaskStartDate(Date taskStartDate) {
		this.taskStartDate = taskStartDate;
	}
	public Date getTaskEndDate() {
		return taskEndDate;
	}
	public void setTaskEndDate(Date taskEndDate) {
		this.taskEndDate = taskEndDate;
	}
	
	
	/**
	 * @return the employees
	 */
	public List<String> getEmployees() {
		return employees;
	}
	/**
	 * @param employees the employees to set
	 */
	public void setEmployees(List<String> employees) {
		this.employees = employees;
	}
	@Override
	public String toString() {
		return "AssignTaskVo [project=" + project + ", taskId=" + taskId + ", taskDescription=" + taskDescription
				+ ", taskStartDate=" + taskStartDate + ", taskEndDate=" + taskEndDate +"]";
	}
	
	
	
}
