package com.mindtree.vo;

import java.util.Set;

import org.apache.log4j.Logger;

import com.mindtree.entity.Employee;

public class TaskViewVo {

	static Logger logger = Logger.getLogger(TaskViewVo.class.getName());
	
	private Integer taskId;
	private String taskDescription;
	private String taskStartDate;
	private String taskEndDate;
	private Set<Employee> employess;
	
	public Integer getTaskId() {
		return taskId;
	}
	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}
	public String getTaskDescription() {
		return taskDescription;
	}
	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}
	public String getTaskStartDate() {
		return taskStartDate;
	}
	public void setTaskStartDate(String taskStartDate) {
		this.taskStartDate = taskStartDate;
	}
	public String getTaskEndDate() {
		return taskEndDate;
	}
	public void setTaskEndDate(String taskEndDate) {
		this.taskEndDate = taskEndDate;
	}
	public Set<Employee> getEmployess() {
		return employess;
	}
	public void setEmployess(Set<Employee> employess) {
		this.employess = employess;
	}
	@Override
	public String toString() {
		return "TaskViewVo [taskId=" + taskId + ", taskDescription=" + taskDescription + ", taskStartDate="
				+ taskStartDate + ", taskEndDate=" + taskEndDate + ", employess=" + employess + "]";
	}
	/**
	 * @param taskId
	 * @param taskDescription
	 * @param taskStartDate
	 * @param taskEndDate
	 * @param employess
	 */
	public TaskViewVo(Integer taskId, String taskDescription, String taskStartDate, String taskEndDate) {
		super();
		this.taskId = taskId;
		this.taskDescription = taskDescription;
		this.taskStartDate = taskStartDate;
		this.taskEndDate = taskEndDate;
		
	}
	
	
}
