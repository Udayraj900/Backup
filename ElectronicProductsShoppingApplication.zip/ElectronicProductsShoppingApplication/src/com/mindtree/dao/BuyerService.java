/**
 * 
 */
package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Product;

/**
 * @author Mkumar
 *
 */
public interface BuyerService {

	List<Product> getProductByCategory(String category);

	List<Product> getProductsByPriceRange(double minPrice, double maxPrice);

	Integer buyProduct(String buyerID, Integer productID);

}
