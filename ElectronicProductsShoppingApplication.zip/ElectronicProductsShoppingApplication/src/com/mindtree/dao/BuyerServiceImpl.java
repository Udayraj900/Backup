/**
 * 
 */
package com.mindtree.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.mindtree.Exception.DaoException;
import com.mindtree.entity.Product;
import com.mindtree.util.DBUtil;
import com.mindtree.util.Query;

/**
 * @author Mkumar
 *
 */
public class BuyerServiceImpl implements BuyerService {
	private Logger logger = Logger.getLogger(BuyerServiceImpl.class.getName());

	@Override
	public List<Product> getProductByCategory(String category) {
		DBUtil dbUtil = new DBUtil();
		Connection connection = null;
		PreparedStatement ps = null;
		List<Product> productList = new ArrayList<Product>();
		try {
			connection = dbUtil.getConnection();
			logger.info("Connection Successful!!!!");
			ps = connection.prepareStatement(Query.FETCH_PRODUCTS_BY_CATEGORY);
			ps.setString(1, category);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Product product = new Product();
				product.setProdID(Integer.parseInt(rs.getString("PRODUCT_ID")));
				product.setProdName(rs.getString("PRODUCT_NAME"));
				product.setProdCategory(rs.getString("PRODUCT_CAT"));
				product.setPrice(Double.parseDouble(rs.getString("PRICE")));
				product.setStock(Integer.parseInt(rs.getString("STOCK")));
				product.setRemarks(rs.getString("REMARKS"));
				product.setSellerID(rs.getString("SELLER_ID"));
				logger.info("Result Set" + product.toString());
				productList.add(product);
			}
		} catch (SQLException | DaoException e) {
			logger.debug("Unable to fetch row due to " + e.getMessage());
			e.printStackTrace();
		}
		return productList;
	}

	@Override
	public List<Product> getProductsByPriceRange(double minPrice, double maxPrice) {

		DBUtil dbUtil = new DBUtil();
		Connection connection = null;
		PreparedStatement ps = null;
		List<Product> productList = new ArrayList<Product>();
		try {
			connection = dbUtil.getConnection();

			ps = connection.prepareStatement(Query.FETCH_PRODUCTS_BY_RANGE);
			ps.setDouble(1, minPrice);
			ps.setDouble(2, maxPrice);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Product product = new Product();
				product.setProdID(Integer.parseInt(rs.getString("PRODUCT_ID")));
				product.setProdName(rs.getString("PRODUCT_NAME"));
				product.setProdCategory(rs.getString("PRODUCT_CAT"));
				product.setPrice(Double.parseDouble(rs.getString("PRICE")));
				product.setStock(Integer.parseInt(rs.getString("STOCK")));
				product.setRemarks(rs.getString("REMARKS"));
				product.setSellerID(rs.getString("SELLER_ID"));
				logger.info("Result Set" + product.toString());
				productList.add(product);
			}
		} catch (SQLException | DaoException e) {
			logger.debug("Unable to fetch row due to " + e.getMessage());
			e.printStackTrace();
		}
		return productList;
	}

	@Override
	public Integer buyProduct(String buyerID, Integer productID) {

		DBUtil dbUtil = new DBUtil();
		Connection connection = null;
		PreparedStatement ps = null;
		int orderID = 0;
		logger.info("Inside Add Order ****");
		try {
			connection = dbUtil.getConnection();
			ps = connection.prepareStatement(Query.INSERT_ORDER, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, buyerID);
			ps.setInt(2, productID);
			ps.executeUpdate();
			ResultSet tableKeys = ps.getGeneratedKeys();
			tableKeys.next();
			orderID = tableKeys.getInt(1);
			logger.info("****************Order Details:" + orderID);
		} catch (SQLException | DaoException e) {
			logger.debug("Unable to add product" + e.getMessage());
		}
		return orderID;

	}

}
