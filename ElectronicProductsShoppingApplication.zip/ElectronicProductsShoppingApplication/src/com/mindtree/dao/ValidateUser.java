/**
 * 
 */
package com.mindtree.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mindtree.Exception.DaoException;
import com.mindtree.entity.User;
import com.mindtree.util.DBUtil;
import com.mindtree.util.Query;

/**
 * @author Mukul
 *
 */
public class ValidateUser {
	DBUtil dbUtil = new DBUtil();
	Connection connection = null;
	PreparedStatement ps = null;

	public User getUser(String userID) {
		User user = new User();
		try {
			connection = dbUtil.getConnection();
			System.out.println("Connection Successful!!!!");
			ps = connection.prepareStatement(Query.GETUSER);
			System.out.println();
			ps.setString(1, userID);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				System.out.println("Result Set" + rs);
				user.setUserID(rs.getString("USER_ID"));
				user.setPassword(rs.getString("password"));
				user.setUserName(rs.getString("USER_NAME"));
				user.setUserCategory(rs.getString("USER_CAT"));
				System.out.println(user.toString());
			}
			rs.close();
		} catch (DaoException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Exception in SQL::" + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception in SQL::" + e.getMessage());
				e.printStackTrace();
			}
		}
		return user;
	}
}
