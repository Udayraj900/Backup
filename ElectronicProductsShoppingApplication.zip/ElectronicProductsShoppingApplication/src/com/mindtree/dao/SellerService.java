/**
 * 
 */
package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Product;

/**
 * @author Mkumar
 *
 */
public interface SellerService {

	Product addProduct(String sellerID, Product product);

	List<Product> getProductBySeller(String sellerID);

	String deleteProduct(String sellerID, Integer productID);

	Product updateProduct(String sellerID, Product product);

}
