/**
 * 
 */
package com.mindtree.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.mindtree.Exception.DaoException;
import com.mindtree.entity.Product;
import com.mindtree.util.DBUtil;
import com.mindtree.util.Query;

/**
 * @author Mkumar
 *
 */
public class SellerServiceImpl implements SellerService {
	private Logger logger = Logger.getLogger(BuyerServiceImpl.class.getName());

	@Override
	public Product addProduct(String sellerID, Product product) {
		DBUtil dbUtil = new DBUtil();
		Connection connection = null;
		PreparedStatement ps = null;
		logger.info("Inside addProduct ****");
		try {
			connection = dbUtil.getConnection();
			ps = connection.prepareStatement(Query.INSERT_PRODUCT, Statement.RETURN_GENERATED_KEYS);
			logger.info("****************Product Details:" + product.toString());
			ps.setString(1, product.getProdName());
			ps.setString(2, product.getProdCategory());
			ps.setDouble(3, product.getPrice());
			ps.setInt(4, product.getStock());
			ps.setString(5, product.getRemarks());
			ps.setString(6, product.getSellerID());
			ps.executeUpdate();
			ResultSet tableKeys = ps.getGeneratedKeys();
			tableKeys.next();
			product.setProdID(tableKeys.getInt(1));
			logger.info("****************Product Details:" + product.toString());
		} catch (SQLException | DaoException e) {
			logger.debug("Unable to add product" + e.getMessage());
		}
		return product;
	}

	@Override
	public List<Product> getProductBySeller(String sellerID) {
		DBUtil dbUtil = new DBUtil();
		Connection connection = null;
		PreparedStatement ps = null;
		List<Product> productList = new ArrayList<Product>();
		try {
			connection = dbUtil.getConnection();
			ps = connection.prepareStatement(Query.FETCH_SELLER_PRODUCTS);

			ps.setString(1, sellerID);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Product product = new Product();
				product.setProdID(Integer.parseInt(rs.getString("PRODUCT_ID")));
				product.setProdName(rs.getString("PRODUCT_NAME"));
				product.setProdCategory(rs.getString("PRODUCT_CAT"));
				product.setPrice(Double.parseDouble(rs.getString("PRICE")));
				product.setStock(Integer.parseInt(rs.getString("STOCK")));
				product.setRemarks(rs.getString("REMARKS"));
				product.setSellerID(rs.getString("SELLER_ID"));
				logger.info("Result Set" + product.toString());
				productList.add(product);
			}
		} catch (SQLException | DaoException e) {
			logger.debug("Unable to fetch row due to " + e.getMessage());
			e.printStackTrace();
		}
		return productList;
	}

	@Override
	public String deleteProduct(String sellerID, Integer productID) {
		final String SUCCESS_RESULT = "success";
		final String FAILURE_RESULT = "failure";
		DBUtil dbUtil = new DBUtil();
		Connection connection = null;
		PreparedStatement ps = null;
		int result = 0;
		logger.info("Inside DeleteProduct ****");
		try {
			connection = dbUtil.getConnection();
			ps = connection.prepareStatement(Query.DELETE_PRODUCT);
			ps.setString(1, sellerID);
			ps.setInt(2, productID);
			result = ps.executeUpdate();
		} catch (SQLException | DaoException e) {
			logger.debug("Unable to add product" + e.getMessage());
		}
		if (result == 1) {
			return SUCCESS_RESULT;
		}
		return FAILURE_RESULT;
	}

	@Override
	public Product updateProduct(String sellerID, Product product) {
		DBUtil dbUtil = new DBUtil();
		Connection connection = null;
		PreparedStatement ps = null;
		logger.info("Inside UpdateProduct ****");
		try {
			connection = dbUtil.getConnection();
			ps = connection.prepareStatement(Query.UPDATE_PRODUCT);
			logger.info("****************Product Details:" + product.toString());
			ps.setString(1, product.getProdName());
			ps.setString(2, product.getProdCategory());
			ps.setDouble(3, product.getPrice());
			ps.setInt(4, product.getStock());
			ps.setString(5, product.getRemarks());
			ps.setInt(6, product.getProdID());
			ps.setString(7, product.getSellerID());
			int result = ps.executeUpdate();
			if (result != 0) {
				return product;
			}
		} catch (SQLException | DaoException e) {
			logger.debug("Unable to add product" + e.getMessage());
		}
		return null;
	}

}
