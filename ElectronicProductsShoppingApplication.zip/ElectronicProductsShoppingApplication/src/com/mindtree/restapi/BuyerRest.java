/**
 * 
 */
package com.mindtree.restapi;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.mindtree.dao.BuyerService;
import com.mindtree.dao.BuyerServiceImpl;
import com.mindtree.entity.Product;

/**
 * @author Mkumar
 *
 */
@Path("/buyers")
public class BuyerRest {
	private Logger logger = Logger.getLogger(BuyerRest.class.getName());
	private BuyerService buyerService = new BuyerServiceImpl();

	@GET
	@Path("/{category}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getCategorywiseProducts(@PathParam("category") String category) {
		logger.info("Getting category wise products details.");
		return buyerService.getProductByCategory(category);

	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getPriceRangeProducts(@QueryParam("minimum") double minPrice,
			@QueryParam("maximum") double maxPrice) {
		logger.info("Getting products by given price range.");
		return buyerService.getProductsByPriceRange(minPrice, maxPrice);

	}

	@POST
	@Path("/{buyerID}/{productID}")
	@Produces(MediaType.TEXT_PLAIN)
	public Integer purchaseProduct(@PathParam("buyerID") String buyerID, @PathParam("productID") Integer productID) {
		logger.info("Buy product with Product ID");
		return buyerService.buyProduct(buyerID, productID);

	}
}
