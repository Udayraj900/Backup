/**
 * 
 */
package com.mindtree.restapi;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.mindtree.dao.SellerService;
import com.mindtree.dao.SellerServiceImpl;
import com.mindtree.entity.Product;

/**
 * @author Mkumar
 *
 */
@Path("/sellers")
public class SellerRest {
	private Logger logger = Logger.getLogger(SellerRest.class.getName());
	private SellerService sellerService = new SellerServiceImpl();

	@POST
	@Path("/{sellerID}")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public Product addProduct(Product product, @PathParam("sellerID") String sellerID) {
		sellerService.addProduct(sellerID, product);
		logger.info("Product details: " + product);
		return product;
	}

	@GET
	@Path("/{sellerID}")
	@Produces(MediaType.APPLICATION_XML)
	public List<Product> fetchProductBySeller(@PathParam("sellerID") String sellerID) {
		logger.info("FetchProductBySeller for --> " + sellerID);
		return sellerService.getProductBySeller(sellerID);
	}

	@DELETE
	@Path("/{sellerId}/{productId}")
	@Produces(MediaType.TEXT_PLAIN)
	public String removeProductBySeller(@PathParam("sellerID") String sellerID,
			@PathParam("productID") Integer productID) {
		logger.info("Deleting a Product" + productID);
		return sellerService.deleteProduct(sellerID, productID);

	}

	@PUT
	@Path("/{sellerId}/{productId}")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public Product updateProduct(@PathParam("sellerID") String sellerID, @PathParam("productID") Integer productID,
			Product product) {
		logger.info("Updating Product: " + productID);
		return sellerService.updateProduct(sellerID, product);
	}
}
