/**
 * 
 */
package com.mindtree.entity;

/**
 * @author Mkumar
 *
 */
public class Address {
	int addressID;
	String localAdd;
	String city;
	int zipCode;
	public int getAddressID() {
		return addressID;
	}
	public void setAddressID(int addressID) {
		this.addressID = addressID;
	}
	public String getLocalAdd() {
		return localAdd;
	}
	public void setLocalAdd(String localAdd) {
		this.localAdd = localAdd;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getZipCode() {
		return zipCode;
	}
	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}
	@Override
	public String toString() {
		return "Address [addressID=" + addressID + ", localAdd=" + localAdd + ", city=" + city + ", zipCode=" + zipCode
				+ "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + addressID;
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((localAdd == null) ? 0 : localAdd.hashCode());
		result = prime * result + zipCode;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		if (addressID != other.addressID)
			return false;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (localAdd == null) {
			if (other.localAdd != null)
				return false;
		} else if (!localAdd.equals(other.localAdd))
			return false;
		if (zipCode != other.zipCode)
			return false;
		return true;
	}
}
