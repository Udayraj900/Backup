/**
 * 
 */
package com.mindtree.entity;

/**
 * @author Mkumar
 *
 */
public class Seller {

	String sellerID;
	String sellerName;
	Address sellerAdd;

	public String getSellerID() {
		return sellerID;
	}

	public void setSellerID(String sellerID) {
		this.sellerID = sellerID;
	}

	public String getSellerName() {
		return sellerName;
	}

	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}

	public Address getSellerAdd() {
		return sellerAdd;
	}

	public void setSellerAdd(Address sellerAdd) {
		this.sellerAdd = sellerAdd;
	}

	@Override
	public String toString() {
		return "Seller [sellerID=" + sellerID + ", sellerName=" + sellerName + ", sellerAdd=" + sellerAdd + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((sellerAdd == null) ? 0 : sellerAdd.hashCode());
		result = prime * result + ((sellerID == null) ? 0 : sellerID.hashCode());
		result = prime * result + ((sellerName == null) ? 0 : sellerName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Seller other = (Seller) obj;
		if (sellerAdd == null) {
			if (other.sellerAdd != null)
				return false;
		} else if (!sellerAdd.equals(other.sellerAdd))
			return false;
		if (sellerID == null) {
			if (other.sellerID != null)
				return false;
		} else if (!sellerID.equals(other.sellerID))
			return false;
		if (sellerName == null) {
			if (other.sellerName != null)
				return false;
		} else if (!sellerName.equals(other.sellerName))
			return false;
		return true;
	}
}
