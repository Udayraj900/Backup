/**
 * 
 */
package com.mindtree.entity;

/**
 * @author Mukul
 *
 */
public class User {
	String userID;
	String password;
	String userName;
	String userCategory;

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserCategory() {
		return userCategory;
	}

	public void setUserCategory(String userCategory) {
		this.userCategory = userCategory;
	}

	@Override
	public String toString() {
		return "User [userID=" + userID + ", password=" + password + ", userName=" + userName + ", userCategory="
				+ userCategory + "]";
	}

}
