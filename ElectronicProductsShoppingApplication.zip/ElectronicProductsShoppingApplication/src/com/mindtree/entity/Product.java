/**
 * 
 */
package com.mindtree.entity;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Mkumar
 *
 */
@XmlRootElement
public class Product {

	String prodName;
	Integer prodID;
	String prodCategory;
	double price;
	int stock;
	String remarks;
	String sellerID;

	@XmlElement
	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	@XmlElement
	public Integer getProdID() {
		return prodID;
	}

	public void setProdID(Integer prodID) {
		this.prodID = prodID;
	}

	@XmlElement
	public String getProdCategory() {
		return prodCategory;
	}

	public void setProdCategory(String prodCategory) {
		this.prodCategory = prodCategory;
	}

	@XmlElement
	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@XmlElement
	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	@XmlElement
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@XmlElement
	public String getSellerID() {
		return sellerID;
	}

	public void setSellerID(String sellerID) {
		this.sellerID = sellerID;
	}

	@Override
	public String toString() {
		return "Product [prodName=" + prodName + ", prodID=" + prodID + ", prodCategory=" + prodCategory + ", price="
				+ price + ", stock=" + stock + ", remarks=" + remarks + ", sellerID=" + sellerID + "]";
	}

}
