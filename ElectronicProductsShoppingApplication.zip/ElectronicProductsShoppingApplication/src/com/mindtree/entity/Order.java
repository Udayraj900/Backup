/**
 * 
 */
package com.mindtree.entity;

/**
 * @author Mukul
 *
 */
public class Order {
	Integer orderID;
	String buyerID;
	Integer productID;

	/**
	 * @return the orderID
	 */
	public Integer getOrderID() {
		return orderID;
	}

	/**
	 * @param orderID the orderID to set
	 */
	public void setOrderID(Integer orderID) {
		this.orderID = orderID;
	}

	/**
	 * @return the buyerID
	 */
	public String getBuyerID() {
		return buyerID;
	}

	/**
	 * @param buyerID
	 *            the buyerID to set
	 */
	public void setBuyerID(String buyerID) {
		this.buyerID = buyerID;
	}

	/**
	 * @return the productID
	 */
	public Integer getProductID() {
		return productID;
	}

	/**
	 * @param productID
	 *            the productID to set
	 */
	public void setProductID(Integer productID) {
		this.productID = productID;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Order [buyerID=" + buyerID + ", productID=" + productID + "]";
	}

}
