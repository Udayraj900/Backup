package com.mindtree.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.mindtree.Exception.DaoException;

/**
 * @author Mkumar
 * 
 */
public class DBUtil {
	final static Logger logger = Logger.getLogger(DBUtil.class.getName());

	/**
	 * Method to get connection to database
	 */
	public static String driver;
	public static String url;
	public static String username;
	public static String password;

	public DBUtil() {
		ResourceBundle resourceBundle = ResourceBundle.getBundle("database");
		driver = resourceBundle.getString("driver");
		url = resourceBundle.getString("url");
		username = resourceBundle.getString("username");
		password = resourceBundle.getString("password");
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			logger.debug("Unable to load driver" + e.getMessage());
		}
	}

	public Connection getConnection() throws DaoException {
		try {
			return DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			throw new DaoException("Unable to connect" + e.getMessage());
		}
	}

	public void closeResource(Connection con) throws DaoException {
		try {
			if (con != null) {
				con.close();
			}
		} catch (SQLException e) {
			throw new DaoException("Unable to release resource..." + e.getMessage());
		}

	}

	public void closeResource(PreparedStatement ps) throws DaoException {
		try {
			if (ps != null) {
				ps.close();
			}
		} catch (SQLException e) {
			throw new DaoException("Unable to release resource..." + e.getMessage());
		}

	}

	public void closeResource(Statement stmt) throws DaoException {
		try {
			if (stmt != null) {
				stmt.close();
			}
		} catch (SQLException e) {
			throw new DaoException("Unable to release resource..." + e.getMessage());
		}
	}
}
