/**
 * 
 */
package com.mindtree.util;

import java.util.Scanner;

import org.apache.log4j.Logger;

/**
 * @author Mkumar
 * 
 */
public class KeyboardUtil {
	static Scanner scanner = new Scanner(System.in);
	static Logger logger = Logger.getLogger(KeyboardUtil.class);

	public static int getInt(String string) {
		logger.info(string);
		int choice = scanner.nextInt();
		return choice;
	}

	public static String getString(String string) {
		logger.info(string);
		string = scanner.next();
		return string;
	}
}
