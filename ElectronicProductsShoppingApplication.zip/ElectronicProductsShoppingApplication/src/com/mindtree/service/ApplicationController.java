package com.mindtree.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.filter.LoggingFilter;

import com.mindtree.dao.ValidateUser;
import com.mindtree.entity.Order;
import com.mindtree.entity.Product;
import com.mindtree.entity.User;
import com.sun.jersey.core.util.Base64;

/**
 * @author Mukul
 *
 *         Servlet implementation class ApplicationManager
 */

public class ApplicationController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ApplicationController() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		String target = "home.jsp";
		String uri = request.getRequestURI();
		HttpSession session = request.getSession(true);
		String userID = null;
		String pass = null;
		try {
			if (uri != null) {
				if (uri.endsWith("login.action")) {
					ValidateUser validateUser = new ValidateUser();
					User user = new User();
					user = validateUser.getUser(request.getParameter("userID"));
					if (user.getPassword().equals(request.getParameter("pass"))) {

						userID = user.getUserID();
						pass = user.getPassword();
						session.setAttribute("userName", user.getUserName());
						session.setAttribute("userID", userID);
						session.setAttribute("password", pass);
						if (user.getUserCategory().equalsIgnoreCase("S")) {
							target = "Seller.jsp";
						}
						if (user.getUserCategory().equalsIgnoreCase("B")) {
							target = "Buyer.jsp";
						}
					} else {
						RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
						request.setAttribute("errMsg", "Either user name or password is wrong.");
						rd.include(request, response);
					}
				}
				if (uri.endsWith("seller.action")) {
					target = "Seller.jsp";
				}
				if (uri.endsWith("buyer.action")) {
					target = "Buyer.jsp";
				}
				if (uri.endsWith("addLink.action")) {
					target = "AddProduct.jsp";
				}
				if (uri.endsWith("updatelink.action")) {
					target = "UpdateProduct.jsp";
				}
				if (uri.endsWith("deletelink.action")) {
					target = "DeleteProduct.jsp";
				}
				if (uri.endsWith("listProdByCat.action")) {
					target = "ViewByCategory.jsp";
				}
				if (uri.endsWith("priceRange.action")) {
					target = "ViewByPriceRange.jsp";
				}
				if (uri.endsWith("orderProduct.action")) {
					System.out.println("Inside orderProduct");

					String authString = (String) session.getAttribute("userID") + ":"
							+ (String) session.getAttribute("password");
					byte[] authStringEnc = Base64.encode(authString.getBytes());

					Order order = new Order();
					String buyerID = request.getParameter("buyerID");
					order.setBuyerID(buyerID);
					String productID = request.getParameter("productID");
					order.setProductID(Integer.parseInt(productID));

					String resourceURI = "http://localhost:8080/ElectronicProductsShoppingApplication/shoppingApi/buyers/";
					Client client = ClientBuilder.newClient(new ClientConfig().register(LoggingFilter.class));
					GenericType<Integer> genOrder = new GenericType<Integer>() {
					};
					Integer orderNumber = 0;
					Integer orderID = client.target(resourceURI).path(buyerID).path(productID)
							.request(MediaType.TEXT_PLAIN).header("Authorization", "Basic " + authStringEnc)
							.post(Entity.entity(orderNumber, MediaType.TEXT_PLAIN), genOrder);

					request.setAttribute("msg", "Order Number: " + orderID + " placed successfully.");
					target = "Buyer.jsp";
				}
				if (uri.endsWith("linkbuyProduct.action")) {

					target = "BuyProduct.jsp";
				}
				if (uri.endsWith("viewByPrice.action")) {

					String authString = (String) session.getAttribute("userID") + ":"
							+ (String) session.getAttribute("password");
					System.out.println("*****" + authString);
					byte[] authStringEnc = Base64.encode(authString.getBytes());

					String minimum = request.getParameter("minimum");
					String maximum = request.getParameter("maximum");

					Client client = ClientBuilder.newClient(new ClientConfig().register(LoggingFilter.class));
					WebTarget webTarget = client
							.target("http://localhost:8080/ElectronicProductsShoppingApplication/shoppingApi")
							.path("/buyers").queryParam("minimum", minimum).queryParam("maximum", maximum);
					GenericType<List<Product>> productList = new GenericType<List<Product>>() {
					};
					List<Product> returnProductList = webTarget.request(MediaType.APPLICATION_JSON)
							.header("Authorization", "Basic " + authStringEnc).get(productList);
					request.setAttribute("productList", returnProductList);
					target = "ViewProduct.jsp";
				}
				if (uri.endsWith("viewByCategory.action")) {

					String authString = (String) session.getAttribute("userID") + ":"
							+ (String) session.getAttribute("password");

					byte[] authStringEnc = Base64.encode(authString.getBytes());

					String category = request.getParameter("category");

					Client client = ClientBuilder.newClient(new ClientConfig().register(LoggingFilter.class));
					WebTarget webTarget = client
							.target("http://localhost:8080/ElectronicProductsShoppingApplication/shoppingApi")
							.path("/buyers").path(category);
					GenericType<List<Product>> productList = new GenericType<List<Product>>() {
					};
					List<Product> returnProductList = webTarget.request(MediaType.APPLICATION_JSON)
							.header("Authorization", "Basic " + authStringEnc).get(productList);

					request.setAttribute("productList", returnProductList);
					target = "ViewProduct.jsp";
				}

				if (uri.endsWith("viewMyProducts.action")) {

					String authString = (String) session.getAttribute("userID") + ":"
							+ (String) session.getAttribute("password");

					byte[] authStringEnc = Base64.encode(authString.getBytes());

					String sellerID = (String) session.getAttribute("userID");

					Client client = ClientBuilder.newClient(new ClientConfig().register(LoggingFilter.class));
					WebTarget webTarget = client
							.target("http://localhost:8080/ElectronicProductsShoppingApplication/shoppingApi")
							.path("/sellers").path(sellerID);
					GenericType<List<Product>> productList = new GenericType<List<Product>>() {
					};
					List<Product> returnProductList = webTarget.request(MediaType.APPLICATION_XML)
							.header("Authorization", "Basic " + authStringEnc).get(productList);

					request.setAttribute("productList", returnProductList);
					target = "ViewProduct.jsp";
				}
				if (uri.endsWith("addProduct.action")) {

					String authString = (String) session.getAttribute("userID") + ":"
							+ (String) session.getAttribute("password");
					byte[] authStringEnc = Base64.encode(authString.getBytes());

					Product product = new Product();
					String productName = request.getParameter("productName");
					product.setProdName(productName);
					String productCategory = request.getParameter("productCategory");
					product.setProdCategory(productCategory);
					double price = Double.parseDouble(request.getParameter("price"));
					product.setPrice(price);
					int stock = Integer.parseInt(request.getParameter("currentStocks"));
					product.setStock(stock);
					String remarks = request.getParameter("remarks");
					product.setRemarks(remarks);
					String sellerID = request.getParameter("sellerID");
					product.setSellerID(sellerID);

					String resourceURI = "http://localhost:8080/ElectronicProductsShoppingApplication/shoppingApi/sellers/";
					Client client = ClientBuilder.newClient(new ClientConfig().register(LoggingFilter.class));
					GenericType<Product> genProduct = new GenericType<Product>() {
					};

					Product returnProduct = client.target(resourceURI).path(sellerID).request(MediaType.APPLICATION_XML)
							.header("Authorization", "Basic " + authStringEnc)
							.post(Entity.entity(product, MediaType.APPLICATION_XML), genProduct);
					request.setAttribute("msg",
							"Product Number: " + returnProduct.getProdID() + " added successfully.");
					target = "Seller.jsp";
				}
				if (uri.endsWith("updateProduct.action")) {

					String authString = (String) session.getAttribute("userID") + ":"
							+ (String) session.getAttribute("password");
					byte[] authStringEnc = Base64.encode(authString.getBytes());

					Product product = new Product();
					String productID = request.getParameter("productID");
					product.setProdID(Integer.parseInt(productID));
					String productName = request.getParameter("productName");
					product.setProdName(productName);
					String productCategory = request.getParameter("productCategory");
					product.setProdCategory(productCategory);
					double price = Double.parseDouble(request.getParameter("price"));
					product.setPrice(price);
					int stock = Integer.parseInt(request.getParameter("currentStocks"));
					product.setStock(stock);
					String remarks = request.getParameter("remarks");
					product.setRemarks(remarks);
					String sellerID = request.getParameter("sellerID");

					product.setSellerID(sellerID);

					String resourceURI = "http://localhost:8080/ElectronicProductsShoppingApplication/shoppingApi/sellers/";
					Client client = ClientBuilder.newClient(new ClientConfig().register(LoggingFilter.class));
					GenericType<Product> genProduct = new GenericType<Product>() {
					};

					Product returnProduct = client.target(resourceURI).path(sellerID).path(productID)
							.request(MediaType.APPLICATION_XML).header("Authorization", "Basic " + authStringEnc)
							.put(Entity.entity(product, MediaType.APPLICATION_XML), genProduct);

					if (returnProduct != null) {
						request.setAttribute("msg",
								"Product Number: " + returnProduct.getProdID() + " updated successfully.");
					} else {
						request.setAttribute("errMsg", "Not able update Product Number: " + product.getProdID());
					}
					target = "Seller.jsp";
				}
				if (uri.endsWith("deleteProduct.action")) {

					String authString = (String) session.getAttribute("userID") + ":"
							+ (String) session.getAttribute("password");
					byte[] authStringEnc = Base64.encode(authString.getBytes());

					String productID = request.getParameter("productID");
					String sellerID = request.getParameter("sellerID");

					String resourceURI = "http://localhost:8080/ElectronicProductsShoppingApplication/shoppingApi/sellers/";
					Client client = ClientBuilder.newClient(new ClientConfig().register(LoggingFilter.class));

					String result = client.target(resourceURI).path(sellerID).path(productID)
							.request(MediaType.TEXT_PLAIN).header("Authorization", "Basic " + authStringEnc)
							.delete(String.class);

					request.setAttribute("msg", "Product Number: " + productID + " Delete - " + result);
					target = "Seller.jsp";
				}
				if (uri.endsWith("buyer.action")) {
					target = "Buyer.jsp";
				}
			}
		} catch (Exception e) {
			request.setAttribute("errMessage", e.getMessage());
			target = "home.jsp";
		}
		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

}
