/**
 * 
 */
package com.mindtree.dao;

import java.awt.event.HierarchyBoundsAdapter;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.mindtree.entity.Employees;
import com.mindtree.entity.Events;
import com.mindtree.exception.DAOException;
import com.mindtree.util.HibernateUtil;

/**
 * @author RShaw
 *
 */
public class EventRegistrationDAOImpl implements EventRegistrationDAO {

	public List<Employees> getAllEmployees() throws DAOException{

		Transaction transaction = null;
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		List<Employees> allEmployees = new ArrayList<Employees>();
		try {
			transaction = session.beginTransaction();

			// allEmployees = session.createCriteria(Employees.class).list();
			// deprecated legacy method

			CriteriaQuery<Employees> query = session.getCriteriaBuilder().createQuery(Employees.class);
			query.from(Employees.class);
			allEmployees = session.createQuery(query).list();

		} catch (HibernateException e) {
			if (transaction != null)
				transaction.rollback();
			throw new DAOException("Couldn't able to get Employees details !!! ");
		} finally {
			session.flush();
			session.close();
		}
		return allEmployees;
	}

	@Override
	public List<Events> getAllEvents() throws DAOException {
		Transaction transaction = null;
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		List<Events> allEvents = new ArrayList<Events>();
		try {
			transaction = session.beginTransaction();
			CriteriaQuery<Events> query = session.getCriteriaBuilder().createQuery(Events.class);
			query.from(Events.class);
			allEvents = session.createQuery(query).list();
		} catch (HibernateException e) {

			if (transaction != null)
				transaction.rollback();
			throw new DAOException("Couldn't able to get Events details !!! ");
		} finally {
			session.flush();
			session.close();
		}
		return allEvents;
	}

	@Override
	public Events saveRegistration(String employeeId, int eventNo) throws DAOException {
		Transaction transaction = null;
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Employees employee = new Employees();
		Events event = new Events();
		
		try {

			transaction = session.beginTransaction();
			employee = session.get(Employees.class, employeeId);

			event = session.get(Events.class, eventNo);

			if (!event.getEmployees().contains(employee)) {
				event.getEmployees().add(employee);
				session.save(event);
				transaction.commit();
				
			} else {
				
				System.err.println("Employee " + employeeId + " is already registered with event " + event.getEventTitle()+" !!!!");
				return null;
			}
		} catch (HibernateException e) {
			if (transaction != null)
				transaction.rollback();
			throw new DAOException("Couldn't able to Registared Employee with Event !!! ");
		} finally {
			// session.flush();
			session.close();
		}
		return event;

	}

}
