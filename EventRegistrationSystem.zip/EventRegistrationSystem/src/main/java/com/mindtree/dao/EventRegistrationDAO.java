/**
 * 
 */
package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Employees;
import com.mindtree.entity.Events;
import com.mindtree.exception.DAOException;

/**
 * @author RShaw
 *
 */
public interface EventRegistrationDAO {

	public List<Employees> getAllEmployees() throws DAOException;

	public List<Events> getAllEvents() throws DAOException;
	
	public Events saveRegistration(String employeeId, int eventNo) throws DAOException;

}
