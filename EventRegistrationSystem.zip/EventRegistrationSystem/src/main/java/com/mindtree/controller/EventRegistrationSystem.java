/**
 * 
 */
package com.mindtree.controller;

import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

import com.mindtree.dto.EventDTO;
import com.mindtree.entity.Employees;
import com.mindtree.entity.Events;
import com.mindtree.exception.DAOException;
import com.mindtree.service.EventRegistrationManager;

/**
 * @author RShaw
 *
 */
public class EventRegistrationSystem {

	static int choice;
	static String userChoice;
	static Scanner userInput = new Scanner(System.in);
	static Scanner userInput1 = new Scanner(System.in);
	static Scanner choiceInput = new Scanner(System.in);

	private static EventRegistrationManager registrationManager = new EventRegistrationManager();

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		displayMenuOnConsole();

	}

	public static void displayMenuOnConsole() {
		boolean exit = false;

		System.out.println("==========================================================");
		System.out.println("********* Welcome to Event Registration System ***********");
		System.out.println("==========================================================");

		do {
			System.out.println("1. Register employee for events");
			System.out.println("2. Display all employees");
			System.out.println("3. Exit");
			System.out.println();
			System.out.print("Enter choice [1-3]: ");

			choice = choiceInput.nextInt();
			switch (choice) {
			case 1:

				System.out.println("--------------------------------------");
				System.out.println("    Register employee for events      ");
				System.out.println("--------------------------------------");

				empolyeeRegistration();

				break;
			case 2:
				System.out.println("--------------------------------");
				System.out.println("     Display all employees      ");
				System.out.println("--------------------------------");

				displayEmployeesDetails();

				break;

			case 3:
				System.out.println("Thank You!!! Please visit again!!!");
				exit = true;
				break;
			default:
				System.out.println("\nInvalid Choice : Please enter between 1-3 ... \n");
			}
		} while (!exit);

	}

	/**
	 * @throws DAOException
	 * @throws NumberFormatException
	 */
	public static void empolyeeRegistration() throws DAOException, NumberFormatException {
		String employeeId;
		int eventNo;
		List<Employees> empList = registrationManager.getAllEmpolyees();
		List<String> mId = empList.stream().map(emp -> emp.getmId()).collect(Collectors.toList());
		System.out.println("Enter the Empolyee ID : " + mId + " : ");
		employeeId = userInput1.nextLine().toUpperCase();

		List<Events> eventList = registrationManager.getAllEvents();
		List<EventDTO> events = eventList.stream()
				.map(eventDTO -> new EventDTO(eventDTO.getEventId(), eventDTO.getEventTitle()))
				.collect(Collectors.toList());
		System.out.println("Enter the Event number [1-4]: " + events + " : ");
		eventNo = Integer.parseInt(userInput1.nextLine());
		Employees employees = (Employees) empList.stream().filter(emp -> emp.getmId().equals(employeeId)).findFirst()
				.get();
		Events event = registrationManager.registerEmployee(employeeId, eventNo);
		if (event != null) {
			System.out.println("Employee " + employees.getEmployeeName() + " is registered with "
					+ event.getEventTitle() + " event. ");
		}
	}

	/**
	 * 
	 */
	public static void displayEmployeesDetails() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		List<Employees> employees = registrationManager.getAllEmpolyees();
		System.out.format("%-10s %-20s %-12s %-20s %-20s", "--------", "----------------", "----------",
				"----------------", "--------------------------------------------");
		System.out.println();
		System.out.format("%-10s %-20s %-12s %-20s %-20s", "MID", "NAME", "JOIN_DATE", "EMAIL_ID", "EVENT_REGISTERED");
		System.out.println();
		System.out.format("%-10s %-20s %-12s %-20s %-20s", "--------", "----------------", "----------",
				"----------------", "--------------------------------------------");
		System.out.println();

		for (Employees employee : employees) {
			Set<String> eventList = new HashSet<String>();
			for (Events empEvent : employee.getEvents()) {
				eventList.add(empEvent.getEventTitle());
			}
			System.out.format("%-10s %-20s %-12s %-20s %-20s", employee.getmId(), employee.getEmployeeName(),
					formatter.format(employee.getJoinDate()), employee.getEmailId(),
					eventList.stream().collect(Collectors.joining(",")));
			System.out.println();
		}

		System.out.println();
	}

}
