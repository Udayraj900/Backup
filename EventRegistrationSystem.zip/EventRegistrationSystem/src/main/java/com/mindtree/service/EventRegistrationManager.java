/**
 * 
 */
package com.mindtree.service;

import java.util.List;

import com.mindtree.dao.EventRegistrationDAO;
import com.mindtree.dao.EventRegistrationDAOImpl;
import com.mindtree.entity.Employees;
import com.mindtree.entity.Events;
import com.mindtree.exception.DAOException;

/**
 * @author RShaw
 *
 */
public class EventRegistrationManager {

	private EventRegistrationDAO eventRegistrationDAOImpl = new EventRegistrationDAOImpl();
	
	public List<Employees> getAllEmpolyees() throws DAOException{
		return eventRegistrationDAOImpl.getAllEmployees();
	}

	public List<Events> getAllEvents() throws DAOException{
		return eventRegistrationDAOImpl.getAllEvents();
	}

	public Events registerEmployee(String employeeId, int eventNo) throws DAOException{
		return eventRegistrationDAOImpl.saveRegistration(employeeId, eventNo);
	}

}
