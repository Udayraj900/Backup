 INSERT INTO EMPLOYEES (MID,NAME,JOIN_DATE,EMAIL_ID) VALUES ("M100100","Karthik Kumar","2013-02-05", "karthik_kumar");
 INSERT INTO EMPLOYEES (MID,NAME,JOIN_DATE,EMAIL_ID) VALUES ("M100108","Ramesh Kulkarni","2013-02-05", "ramesh_kulkarni");
 INSERT INTO EMPLOYEES (MID,NAME,JOIN_DATE,EMAIL_ID) VALUES ("M100189","Rohit Agarwal M","2013-03-22", "rohit_agarwal_m");
 INSERT INTO EMPLOYEES (MID,NAME,JOIN_DATE,EMAIL_ID) VALUES ("M101190","Magesh Narayanan","2013-03-22", "magesh_narayanan");
 INSERT INTO EVENTS (EVENT_ID,EVENT_TITLE,DESCRIPTION) VALUES (1,"Trekking","Held every month. MOre details from Manish Kumar.");
 INSERT INTO EVENTS (EVENT_ID,EVENT_TITLE,DESCRIPTION) VALUES (2,"Guitar Classes","Weekly 3 sessions. Classes conducted by Daniel M.");
 INSERT INTO EVENTS (EVENT_ID,EVENT_TITLE,DESCRIPTION) VALUES (3,"Yoga Classes","Saturdays and Sundays. Classes conducted by Yamini.");
 INSERT INTO EVENTS (EVENT_ID,EVENT_TITLE,DESCRIPTION) VALUES (4,"Health & Diet tips","Every Friday 5 PM to 6 PM by Dr.Kishor Dutta.");