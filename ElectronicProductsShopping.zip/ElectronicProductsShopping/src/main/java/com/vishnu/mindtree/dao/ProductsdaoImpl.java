package com.vishnu.mindtree.dao;

import java.util.List; 

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.vishnu.mindtree.entity.Product;
import com.vishnu.mindtree.entity.Shop;

/**
 * @author Vishnu
 *
 */
public class ProductsdaoImpl implements ProductDao {

	@SuppressWarnings("deprecation")
	private  SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

	@SuppressWarnings("unchecked")
	public List<Product> getProducts() {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		String hql = "from Product";
		Query query = session.createQuery(hql);
		List<Product> productList = query.list();
		transaction.commit();
		session.close();
		return productList;
	}

	@SuppressWarnings("unchecked")
	public Product getProduct(int productId) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		String hql = "from Product where productId=" + productId;
		Query query = session.createQuery(hql);
		List<Product> productList = query.list();
		if (productList.size() != 0) {
			Product product = productList.get(0);
			transaction.commit();
			session.close();
			return product;
		}
		return null;
	}

	public Product addProduct(Product product) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Product product2 = new Product();
		int price = product.getPrice();
		String productCategeory = product.getProductCategory();
		int stockNumber = product.getCurrentStockNumbers();
		String remarks = product.getRemarks();
		String productName = product.getProductName();
		product2.setCurrentStockNumbers(stockNumber);
		product2.setPrice(price);
		product2.setProductName(productName);
		product2.setRemarks(remarks);
		product2.setProductCategory(productCategeory);
		session.save(product2);
		transaction.commit();
		session.close();
		return product2;
	}

	public Product updateProduct(Product product) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		transaction.commit();
		session.save(product);
		session.close();
		return product;
	}

	public void removeProduct(int productId) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		String hql = "delete from Product where productId=" + productId;
		Query query = session.createQuery(hql);
		query.executeUpdate();
		transaction.commit();
		session.close();

	}


	@SuppressWarnings({ "unchecked", "unused" })
	public List<Product> getProductbyCategory(String productCategory) {
		System.out.println(productCategory);
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		String hql = "from Product where productCategory= :productCategory";
		Query query = session.createQuery(hql);
		query.setParameter("productCategory",productCategory);
		List<Product> productList = query.list();
		if (productList.size() != 0) {
			Product product = productList.get(0);
			transaction.commit();
			session.close();
			return productList;
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public List<Product> getProductbyPrice(int productPrice) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		String hql = "from Product where price >" + productPrice;
		Query query = session.createQuery(hql);
		List<Product> productList = query.list();
		if (productList.size() != 0) {
			transaction.commit();
			session.close();
			return productList;
		}
		return null;
	}

	public Shop buyProduct(Product product) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		int productId = product.getProductId();
		String hql = "from Product where productName =" + productId;
		Query query = session.createQuery(hql);
		if (query.list() != null) {
			transaction.commit();
			session.close();
			Shop shopped = new Shop();
			shopped.setProduct(product);
			return shopped;
		}
		return null;
	}
}
