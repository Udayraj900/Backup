package com.vishnu.mindtree.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.filter.LoggingFilter;

import com.sun.jersey.core.util.Base64;
import com.vishnu.mindtree.entity.Product;

/**
 * Servlet implementation class UpdateProduct
 */
/**
 * @author Vishnu
 *
 */
@WebServlet("/updateProduct")
public class UpdateProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateProduct() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = "vishnu";
		String password = "admin";
		String authString = name + ":" + password;
		byte[] authStringEnc = Base64.encode(authString.getBytes());
		System.out.println("Base64 encoded auth string: " + authStringEnc);
		Product product = new Product();
		product.setProductName(request.getParameter("productName"));
		product.setPrice(Integer.parseInt(request.getParameter("price")));
		product.setCurrentStockNumbers(Integer.parseInt(request.getParameter("currentStockNumbers")));
		product.setProductCategory(request.getParameter("productCategory"));
		product.setRemarks(request.getParameter("remarks"));
		Client client = ClientBuilder.newClient(new ClientConfig().register(LoggingFilter.class));
		WebTarget webTarget = client.target("http://localhost:8080/ElectronicProductsShopping/webapp")
				.path("/products");
		Invocation.Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_XML).header("Authorization",
				"Basic " + authStringEnc);
		Response response1 = invocationBuilder.put(Entity.entity(product, MediaType.APPLICATION_XML));
		PrintWriter pw = response.getWriter();
		pw.write(response1.getStatus());
		if (response1.getStatus() == 200) {
			String message = "Product Updated successfully";
			request.setAttribute("message", message);
			RequestDispatcher view = request.getRequestDispatcher("UpdateProduct.jsp");
			view.forward(request, response);
		}
	}

}
