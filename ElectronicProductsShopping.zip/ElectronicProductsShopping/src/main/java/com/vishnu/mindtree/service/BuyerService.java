package com.vishnu.mindtree.service;

import java.util.List;

import com.vishnu.mindtree.dao.ProductDao;
import com.vishnu.mindtree.dao.ProductsdaoImpl;
import com.vishnu.mindtree.entity.Product;
import com.vishnu.mindtree.entity.Shop;


/**
 * @author Vishnu
 *
 */
public class BuyerService {

	ProductsdaoImpl productsDao = new ProductsdaoImpl();

	public List<Product> getProductbyCategory(String productCategory) {
		List<Product> productList = productsDao.getProductbyCategory(productCategory);
		return productList;
	}

	public List<Product> getProductbyPrice(int productPrice) {
		List<Product> productList = productsDao.getProductbyPrice(productPrice);
		return productList;
	}

	public Shop buyProduct(Product product) {
		Shop shopped = productsDao.buyProduct(product);
		return shopped;
	}


}
