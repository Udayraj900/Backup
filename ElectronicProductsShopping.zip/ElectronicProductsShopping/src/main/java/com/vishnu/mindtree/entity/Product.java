package com.vishnu.mindtree.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author Vishnu
 *
 */
@XmlRootElement
@Entity
@Table(name = "product")
public class Product {
	@Id
	@Column(name = "Id")
	@GenericGenerator(name = "gen", strategy = "increment")
	@GeneratedValue(generator = "gen")
	private int productId;
	@Column(name = "productname")
	private String productName;
	@Column(name = "productcategory")
	private String productCategory;
	@Column(name = "price")
	private int price;
	@Column(name = "currentstockNumbers")
	private int currentStockNumbers;
	@Column(name = "remarks")
	private String remarks;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getCurrentStockNumbers() {
		return currentStockNumbers;
	}

	public void setCurrentStockNumbers(int currentStockNumbers) {
		this.currentStockNumbers = currentStockNumbers;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(int productId, String productName, String productCategory, int price, int currentStockNumbers,
			String remarks) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productCategory = productCategory;
		this.price = price;
		this.currentStockNumbers = currentStockNumbers;
		this.remarks = remarks;
	}

}
