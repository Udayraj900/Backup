package com.vishnu.mindtree.servlet;

import java.io.IOException; 
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.filter.LoggingFilter;

import com.sun.jersey.core.util.Base64;
import com.vishnu.mindtree.entity.Product;

/**
 * Servlet implementation class getProductByCategory
 */
/**
 * @author Vishnu
 *
 */
@WebServlet("/getProductByCategory")
public class GetProductByCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GetProductByCategory() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = "vishnu";
		String password = "admin";
		String authString = name + ":" + password;
		byte[] authStringEnc = Base64.encode(authString.getBytes());
		System.out.println("Base64 encoded auth string: " + authStringEnc);
		String productCategory = request.getParameter("productCategory");
		Client client = ClientBuilder.newClient(new ClientConfig().register(LoggingFilter.class));
		WebTarget webTarget = client.target("http://localhost:8080/ElectronicProductsShopping/webapp").path("/products")
				.path(productCategory);
		GenericType<List<Product>> list = new GenericType<List<Product>>() {
		};
		List<Product> productList = webTarget.request(MediaType.APPLICATION_JSON)
				.header("Authorization", "Basic " + authStringEnc).get(list);
		PrintWriter out = response.getWriter();
		if (productList.size()== 0) {
			out.write("<html><head>No results found</head></html>");
		} else {
			out.write("<html><head> Product List </head><body>");
			for (Product product : productList) {
				out.write("id       :" + product.getProductId() + "</br>");
				out.write("name     :" + product.getProductName() + "</br>");
				out.write("category :" + product.getProductCategory() + "</br>");
				out.write("price    :" + product.getPrice() + "</br>");
				out.write("Stock no.:" + product.getCurrentStockNumbers() + "</br>");
				out.write("remarks  :" + product.getRemarks() + "</br>");

				out.write("</body></html>");
			}
		}

	}

}
