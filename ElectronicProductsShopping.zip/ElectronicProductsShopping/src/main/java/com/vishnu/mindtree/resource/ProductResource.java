package com.vishnu.mindtree.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.vishnu.mindtree.entity.Product;
import com.vishnu.mindtree.entity.Shop;
import com.vishnu.mindtree.service.BuyerService;
import com.vishnu.mindtree.service.SellerService;

/**
 * @author Vishnu
 *
 */
@Path("/products")
public class ProductResource {

	SellerService sellerService = new SellerService();
	BuyerService buyerService = new BuyerService();

	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Product> getAllProducts() {
		return sellerService.getAllProducts();
	}

	@GET
	@Path("/{productId}")
	@Produces(MediaType.APPLICATION_XML)
	public Product getProductbyId(@PathParam("productId") int productId) {
		return sellerService.getProduct(productId);
	}

	@POST
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public Product addProduct(Product product) {
		return sellerService.addProduct(product);
	}

	@PUT
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_XML)
	public Product updateProduct(Product product) {
		return sellerService.updateProduct(product);
	}

	@DELETE
	@Path("/{productId}")
	@Produces(MediaType.APPLICATION_XML)
	public void deleteProduct(@PathParam("productId") int productId) {
		sellerService.removeProduct(productId);
	}

	@GET
	@Path("/{productCategory}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getProductbyproductCategory(@PathParam("productCategory") String productCategory) {
		return buyerService.getProductbyCategory(productCategory);
	}

	@GET
	@Path("/>{productPrice}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getProductbyproductPrice(@PathParam("productPrice") int productPrice) {
		return buyerService.getProductbyPrice(productPrice);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Shop addShoppedProduct(Product product) {
		return buyerService.buyProduct(product);
	}

}
