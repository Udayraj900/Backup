package com.vishnu.mindtree.service;

import java.util.List;

import com.vishnu.mindtree.dao.ProductDao;
import com.vishnu.mindtree.dao.ProductsdaoImpl;
import com.vishnu.mindtree.entity.Product;


/**
 * @author Vishnu
 *
 */
public class SellerService {

	ProductsdaoImpl productsDao = new ProductsdaoImpl();

	public List<Product> getAllProducts() {
		List<Product> productList = productsDao.getProducts();
		return productList;
	}

	public Product getProduct(int productId) {
		Product product = productsDao.getProduct(productId);
		return product;
	}

	public Product addProduct(Product product) {
		Product product1 = productsDao.addProduct(product);
		return product1;
	}

	public Product updateProduct(Product product) {
		Product product1 = productsDao.updateProduct(product);
		return product1;
	}

	public void removeProduct(int productId) {
		productsDao.removeProduct(productId);

	}

}
