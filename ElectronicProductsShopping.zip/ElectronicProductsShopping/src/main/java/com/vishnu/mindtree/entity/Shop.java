package com.vishnu.mindtree.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author Vishnu
 *
 */
@XmlRootElement
@Entity
@Table(name = "shop")
public class Shop {
	@Id
	@Column(name = "Id")
	@GenericGenerator(name = "gen", strategy = "increment")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@ManyToOne(targetEntity = Product.class)
	@JoinColumn(name = "productId")
	@Column(name = "productId")
	private Product product;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Shop(int id, Product product) {
		super();
		this.id = id;
		this.product = product;
	}

	public Shop() {
		super();
		// TODO Auto-generated constructor stub
	}

}
